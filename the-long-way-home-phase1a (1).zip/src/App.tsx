import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import {
  EnvironmentBuildId,
  FLAME_CHOICES,
  FlameId,
  POSTCARDS,
  PREWRITTEN_WISH,
  STORY_BEATS
} from './data/storyData';
import { MiniatureWorldCanvas } from './components/MiniatureWorldCanvas';
import { LanternHeroRig } from './components/LanternHeroRig';
import { PostcardModal } from './components/PostcardModal';
import { soundEngine } from './utils/soundEngine';
import {
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Compass,
  Eye,
  Flame,
  Hand,
  Layers,
  Sparkles,
  Volume2,
  VolumeX
} from 'lucide-react';

// Developer-only tooling (stage audit drawer, scene jump, lantern inspector).
// import.meta.env.DEV is false in production builds, so this branch and the dev/ folder
// are removed from the shipped bundle.
const DEV_TOOLS = import.meta.env.DEV;
const StageReviewDrawer = import.meta.env.DEV
  ? lazy(() =>
      import('./dev/StageReviewDrawer').then((m) => ({ default: m.StageReviewDrawer }))
    )
  : null;

export function App() {
  // Core Story & Lantern State
  const [currentBeat, setCurrentBeat] = useState<number>(1);
  const [environmentOverride, setEnvironmentOverride] =
    useState<EnvironmentBuildId | null>(null);
  const [flameId, setFlameId] = useState<FlameId>('honey-gold');
  const [unfoldProgress, setUnfoldProgress] = useState<number>(0); // 0 = folded, 1 = unfolded
  const [wishFolded, setWishFolded] = useState<boolean>(false);
  const [streetExploreProgress, setStreetExploreProgress] = useState<number>(0);
  const [waterExploreProgress, setWaterExploreProgress] = useState<number>(0);
  const [collectedPostcards, setCollectedPostcards] = useState<number[]>([]);

  // Active Modals & Drawers
  const [activePostcardId, setActivePostcardId] = useState<number | null>(null);
  const [isStageDrawerOpen, setIsStageDrawerOpen] = useState<boolean>(false);
  const [isSketchbookOpen, setIsSketchbookOpen] = useState<boolean>(false);
  const [lanternCloseupOpen, setLanternCloseupOpen] = useState<boolean>(false);

  // Sound & Reduced Motion
  const [soundEnabled, setSoundEnabled] = useState<boolean>(false);
  const [reducedMotion, setReducedMotion] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    return false;
  });

  // Deliberate 1-second Hold State (for Beat 1 Lantern Unfold & Beat 8 Library Lectern)
  const [isHolding, setIsHolding] = useState<boolean>(false);
  const [libraryHoldProgress, setLibraryHoldProgress] = useState<number>(0);
  const holdRafRef = useRef<number | null>(null);
  const holdStartRef = useRef<number | null>(null);

  const activeFlame = FLAME_CHOICES[flameId];
  const beat =
    STORY_BEATS.find((b) => b.beatNumber === currentBeat) || STORY_BEATS[0];

  // Sync CSS Custom Properties with chosen flame colour
  useEffect(() => {
    document.documentElement.style.setProperty('--flame-primary', activeFlame.primaryHex);
    document.documentElement.style.setProperty('--flame-core', activeFlame.coreHex);
    document.documentElement.style.setProperty('--flame-bounce', activeFlame.bounceHex);
  }, [activeFlame]);

  // Cancel any in-flight hold animation if the app unmounts
  useEffect(() => {
    return () => {
      if (holdRafRef.current) cancelAnimationFrame(holdRafRef.current);
    };
  }, []);

  // Listen to system reduced-motion preference changes
  useEffect(() => {
    if (!window.matchMedia) return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  // Ensure lantern is unfolded if user jumps ahead past Beat 1
  const navigateToBeat = (targetBeat: number) => {
    setEnvironmentOverride(null);
    if (targetBeat > 1 && unfoldProgress < 1) {
      setUnfoldProgress(1);
    }
    if (targetBeat > 3 && !wishFolded) {
      setWishFolded(true);
    }
    setCurrentBeat(Math.max(1, Math.min(9, targetBeat)));
  };

  // Deliberate 1.0-Second Hold Gesture Handler (Beat 1 Unfold Lantern)
  const startLanternHold = () => {
    if (unfoldProgress >= 1) return;
    setIsHolding(true);
    const startVal = unfoldProgress;
    holdStartRef.current = performance.now();

    const step = (now: number) => {
      if (!holdStartRef.current) return;
      const elapsed = now - holdStartRef.current;
      // 1000ms (1 second) deliberate hold
      const nextProgress = Math.min(1, startVal + elapsed / 1000);
      setUnfoldProgress(nextProgress);

      if (nextProgress < 1) {
        holdRafRef.current = requestAnimationFrame(step);
      } else {
        setIsHolding(false);
        soundEngine.playPaperFold();
        soundEngine.playChime(1.0);
      }
    };

    holdRafRef.current = requestAnimationFrame(step);
  };

  const stopLanternHold = () => {
    setIsHolding(false);
    if (holdRafRef.current) {
      cancelAnimationFrame(holdRafRef.current);
      holdRafRef.current = null;
    }
    holdStartRef.current = null;
  };

  // Deliberate 1-second Hold or Tap for Beat 8 Library Lectern
  const startLibraryHold = () => {
    setIsHolding(true);
    const startVal = libraryHoldProgress;
    holdStartRef.current = performance.now();

    const step = (now: number) => {
      if (!holdStartRef.current) return;
      const elapsed = now - holdStartRef.current;
      const next = Math.min(1, startVal + elapsed / 900);
      setLibraryHoldProgress(next);
      if (next < 1) {
        holdRafRef.current = requestAnimationFrame(step);
      } else {
        setIsHolding(false);
        handleLeavePostcard(4);
      }
    };
    holdRafRef.current = requestAnimationFrame(step);
  };

  const handleSelectFlame = (newFlame: FlameId) => {
    setFlameId(newFlame);
    if (unfoldProgress < 1) setUnfoldProgress(1);
    const pitchMap: Record<FlameId, number> = {
      'honey-gold': 1.0,
      'almost-white': 1.25,
      'deep-rose': 0.88,
      'green-gold': 1.12
    };
    soundEngine.playChime(pitchMap[newFlame]);
  };

  const handleFoldWish = () => {
    soundEngine.playPaperFold();
    soundEngine.playChime(1.15);
    setWishFolded(true);
  };

  const handleLeavePostcard = (postcardId: number) => {
    soundEngine.playPaperFold();
    soundEngine.playChime(1 + postcardId * 0.08);
    setCollectedPostcards((prev) =>
      prev.includes(postcardId) ? prev : [...prev, postcardId]
    );
    setActivePostcardId(postcardId);
  };

  const handleCanvasDragProgress = (delta: number) => {
    if (currentBeat === 4 || environmentOverride === 'sleeping-street') {
      setStreetExploreProgress((prev) => Math.min(1, prev + delta));
    } else if (currentBeat === 6 || environmentOverride === 'water') {
      setWaterExploreProgress((prev) => Math.min(1, prev + delta));
    }
  };

  const handleToggleSound = () => {
    const next = soundEngine.toggle();
    setSoundEnabled(next);
  };

  const activePostcardObj =
    POSTCARDS.find((p) => p.id === activePostcardId) || null;

  return (
    <div className="relative w-full h-dvh overflow-hidden bg-[#080d1a] text-[#f4efe6] flex flex-col justify-between select-none">
      {/* FULL-VIEWPORT 3D STORYBOOK MINIATURE WORLD CANVAS */}
      <div className="absolute inset-0 z-0">
        <MiniatureWorldCanvas
          currentBeat={currentBeat}
          environmentOverride={environmentOverride}
          flameId={flameId}
          unfoldProgress={unfoldProgress}
          wishFolded={wishFolded}
          collectedPostcards={collectedPostcards}
          reducedMotion={reducedMotion}
          lanternInspectionMode={lanternCloseupOpen}
          onDragProgress={handleCanvasDragProgress}
        />

        {/* Soft cinematic vignette & blue-hour atmospheric frame */}
        <div
          className="pointer-events-none absolute inset-0 transition-colors duration-700"
          style={{
            background: `radial-gradient(circle at 50% 45%, transparent 38%, rgba(6, 10, 22, 0.68) 100%)`
          }}
        />
      </div>

      {/* =====================================================================
          TOP NAVIGATION & STAGE INSPECTION BAR
         ===================================================================== */}
      <header className="relative z-20 px-3 sm:px-6 pt-3 pb-2 flex flex-wrap items-center justify-between gap-2 bg-gradient-to-b from-[#060a14]/90 via-[#060a14]/55 to-transparent">
        {/* Left: Project Title & Recipient */}
        <div className="flex items-center gap-3">
          <div
            className="w-2.5 h-2.5 rounded-full transition-all duration-500"
            style={{
              backgroundColor: activeFlame.primaryHex,
              boxShadow: `0 0 12px ${activeFlame.primaryHex}`
            }}
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-story text-lg sm:text-xl font-medium tracking-wide text-[#fbf5e9]">
                The Long Way Home
              </h1>
              <span className="hidden md:inline-block text-[10px] uppercase tracking-[0.2em] px-2 py-0.5 rounded-full bg-white/10 text-[#e6c487]">
                For Anamcara
              </span>
            </div>
            <p className="text-[11px] text-[#b9c5d8] hidden sm:block">
              {environmentOverride
                ? `Stage Preview Mode · Inspecting ${environmentOverride.replace('-', ' ')}`
                : `${beat.environmentLabel} · ${beat.beatNumber} of 9`}
            </p>
          </div>
        </div>

        {/* Center/Right Controls: Flame Switcher, Scene 02 Shortcut, Postcards, Sound, Stage Audit */}
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
          {/* Quick Flame Colour Pill (Changes the SAME lantern across all environments) */}
          <div
            className="flex items-center gap-1 px-2 py-1 rounded-full bg-[#0e1729]/90 border border-white/15 backdrop-blur-md"
            title="Switch the lantern's flame colour across the environment"
          >
            <Flame
              className="w-3.5 h-3.5 mr-0.5"
              style={{ color: activeFlame.primaryHex }}
            />
            {(Object.keys(FLAME_CHOICES) as FlameId[]).map((id) => {
              const f = FLAME_CHOICES[id];
              const isSelected = flameId === id;
              return (
                <button
                  key={id}
                  onClick={() => handleSelectFlame(id)}
                  className={`w-5 h-5 rounded-full transition flex items-center justify-center cursor-pointer ${
                    isSelected
                      ? 'ring-2 ring-white scale-110'
                      : 'opacity-70 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: f.primaryHex }}
                  aria-label={`Select ${f.name} flame (${f.subtitle})`}
                  title={`${f.name} — ${f.subtitle}`}
                />
              );
            })}
          </div>

{DEV_TOOLS && (
<>
          {/* Direct Shortcut to Stage 3: Scene 02 — The Sleeping Street */}
          <button
            onClick={() => {
              setEnvironmentOverride(null);
              navigateToBeat(4);
            }}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-medium border transition cursor-pointer ${
              currentBeat === 4 || currentBeat === 5
                ? 'bg-[#f6b94d] text-[#121826] border-[#f6b94d]'
                : 'bg-[#0e1729]/85 text-[#e8dfd1] border-[#d4a853]/35 hover:bg-[#192642]'
            }`}
            title="Jump directly to Scene 02 — The Sleeping Street"
          >
            <Compass className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Scene 02:</span>
            <span>Sleeping Street</span>
          </button>
</>
)}

          {DEV_TOOLS && (
<>
          {/* Lantern Close-up Rig Toggle */}
          <button
            onClick={() => setLanternCloseupOpen((prev) => !prev)}
            className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-full text-xs border transition cursor-pointer ${
              lanternCloseupOpen
                ? 'bg-[#f6b94d] text-[#121826] border-[#f6b94d]'
                : 'bg-[#0e1729]/85 text-[#e8dfd1] border-white/15 hover:bg-white/15'
            }`}
            title="Inspect the approved lantern rig in close-up"
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Lantern Rig</span>
          </button>
</>
)}

                    {/* Sketchbook & 5 Postcards Collection Button */}
          <button
            onClick={() => setIsSketchbookOpen(true)}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs bg-[#0e1729]/85 hover:bg-white/15 text-[#f4ead8] border border-white/15 transition cursor-pointer"
            aria-label="Open Sketchbook and Postcards"
          >
            <BookOpen className="w-3.5 h-3.5 text-[#f6b94d]" />
            <span className="hidden sm:inline">Postcards</span>
            <span className="px-1.5 py-0.2 rounded-full bg-[#f6b94d]/20 text-[#f6b94d] font-medium">
              {collectedPostcards.length}/5
            </span>
          </button>

          {/* Optional Sound Toggle (Off by default) */}
          <button
            onClick={handleToggleSound}
            className={`p-1.5 rounded-full border transition cursor-pointer ${
              soundEnabled
                ? 'bg-[#f6b94d]/20 border-[#f6b94d] text-[#f6b94d]'
                : 'bg-[#0e1729]/85 border-white/15 text-[#b8c4d6] hover:text-white'
            }`}
            aria-label={soundEnabled ? 'Mute optional soundscape' : 'Enable optional gentle soundscape'}
            title={
              soundEnabled
                ? 'Soundscape: On (Tap to turn off)'
                : 'Soundscape: Off by default (Tap to enable)'
            }
          >
            {soundEnabled ? (
              <Volume2 className="w-3.5 h-3.5" />
            ) : (
              <VolumeX className="w-3.5 h-3.5" />
            )}
          </button>

{DEV_TOOLS && (
<>
          {/* Stage Audit & Creative Director Review Drawer Button */}
          <button
            onClick={() => setIsStageDrawerOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium bg-[#182644] hover:bg-[#22345c] text-[#f6d38c] border border-[#d4a853]/45 transition cursor-pointer"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Stage Audit & Review</span>
          </button>
</>
)}
        </div>
      </header>

      {/* =====================================================================
          CENTER FOREGROUND: LANTERN VERIFICATION OR BEAT 1-3 INTERACTIVE RIG
         ===================================================================== */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 pointer-events-none">
        {/* Close-up Lantern Rig Overlay (Active on Doorstep Beats 1-3 or when Lantern Rig Inspector is toggled) */}
        {(currentBeat <= 3 || lanternCloseupOpen) && !environmentOverride && (
          <div className="pointer-events-auto flex flex-col items-center">
            <div
              onPointerDown={currentBeat === 1 ? startLanternHold : undefined}
              onPointerUp={currentBeat === 1 ? stopLanternHold : undefined}
              onPointerLeave={currentBeat === 1 ? stopLanternHold : undefined}
              onPointerCancel={currentBeat === 1 ? stopLanternHold : undefined}
              className={`relative group ${
                currentBeat === 1 && unfoldProgress < 1 ? 'cursor-pointer' : ''
              }`}
            >
              <LanternHeroRig
                flameId={flameId}
                unfoldProgress={unfoldProgress}
                wishFolded={wishFolded}
                isHolding={isHolding}
                showCallouts={lanternCloseupOpen}
                size={lanternCloseupOpen ? 'large' : 'normal'}
              />

              {/* Hold Progress Ring Overlay during Beat 1 Unfold */}
              {currentBeat === 1 && unfoldProgress < 1 && (
                <div className="mt-1 flex flex-col items-center">
                  <div className="w-44 h-2 rounded-full bg-white/15 overflow-hidden border border-white/20">
                    <div
                      className="h-full transition-all duration-75"
                      style={{
                        width: `${Math.round(unfoldProgress * 100)}%`,
                        backgroundColor: activeFlame.primaryHex
                      }}
                    />
                  </div>
                  <span className="text-[11px] text-[#e6c487] mt-1 font-medium tracking-wide">
                    {isHolding
                      ? `Unfolding bamboo ribs… ${Math.round(unfoldProgress * 100)}%`
                      : 'Press & hold lantern for 1 second to unfold'}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Subtle Interactive Drag Hint Pill for Scene 02 (Sleeping Street) & Scene 03 (Water) */}
        {(currentBeat === 4 || currentBeat === 6 || environmentOverride === 'sleeping-street') &&
          !lanternCloseupOpen && (
            <div className="pointer-events-none mb-auto mt-3 px-3.5 py-1.5 rounded-full bg-[#09101f]/75 border border-white/15 backdrop-blur-md text-xs text-[#e5dac7] flex items-center gap-2 shadow-lg">
              <Hand className="w-3.5 h-3.5 text-[#f6b94d]" />
              <span>
                Drag anywhere across the miniature scene to guide the{' '}
                <strong style={{ color: activeFlame.primaryHex }}>
                  {activeFlame.name.toLowerCase()}
                </strong>{' '}
                lantern light
              </span>
            </div>
          )}
      </main>

      {/* =====================================================================
          BOTTOM STORYBOOK NARRATIVE & GESTURE PANEL
         ===================================================================== */}
      <footer className="relative z-20 px-3 sm:px-6 pb-3 sm:pb-5 pt-2 flex flex-col items-center">
        <div className="w-full max-w-3xl dark-plaster-panel rounded-2xl border border-[#d4a853]/30 p-4 sm:p-5 shadow-[0_18px_50px_rgba(0,0,0,0.75)]">
          {/* Top Beat Progress Dots (9 Beats) */}
          <div className="flex items-center justify-between gap-2 mb-3 pb-2.5 border-b border-white/10">
            <div className="flex items-center gap-1.5">
              {STORY_BEATS.map((b) => {
                const isActive = currentBeat === b.beatNumber;
                const isPassed = currentBeat > b.beatNumber;
                return (
                  <button
                    key={b.beatNumber}
                    onClick={() => navigateToBeat(b.beatNumber)}
                    className={`h-2 rounded-full transition-all cursor-pointer ${
                      isActive
                        ? 'w-7 bg-[#f6b94d]'
                        : isPassed
                        ? 'w-2.5 bg-[#f6b94d]/55 hover:bg-[#f6b94d]'
                        : 'w-2.5 bg-white/20 hover:bg-white/40'
                    }`}
                    title={`${b.beatNumber}. ${b.title}`}
                    aria-label={`Go to ${b.title} (${b.beatNumber} of 9)`}
                  />
                );
              })}
            </div>

            <span className="text-[11px] uppercase tracking-[0.16em] text-[#d8c4a0]">
              {beat.subtitle}
            </span>
          </div>

          {/* Story Beat Content or Beat 9 Fixed Ending */}
          {currentBeat < 9 ? (
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
                <h2 className="font-story text-2xl sm:text-3xl font-medium text-[#fbf5e8]">
                  {beat.title}
                </h2>
                <span className="text-xs italic font-narrative text-[#cbb894]">
                  “{beat.sketchbookNote}”
                </span>
              </div>

              <div className="space-y-1.5 font-narrative text-xs sm:text-sm text-[#e2dbd0] leading-relaxed">
                {beat.narrativeParagraphs.map((p, idx) => (
                  <p key={idx}>{p}</p>
                ))}
              </div>

              {/* BEAT-SPECIFIC TACTILE GESTURE CONTROLS (Hold / Tap / Drag) */}
              <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-white/10">
                {/* BEAT 1: 1-SECOND HOLD TO UNFOLD LANTERN */}
                {currentBeat === 1 && (
                  <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
                    {unfoldProgress < 1 ? (
                      <>
                        <button
                          onPointerDown={startLanternHold}
                          onPointerUp={stopLanternHold}
                          onPointerLeave={stopLanternHold}
                          onPointerCancel={stopLanternHold}
                          className="no-select-gesture inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-xs sm:text-sm text-[#121826] transition shadow-md cursor-pointer"
                          style={{
                            backgroundColor: activeFlame.primaryHex
                          }}
                        >
                          <Hand className="w-4 h-4" />
                          <span>
                            {isHolding
                              ? `Hold Steady… ${Math.round(unfoldProgress * 100)}%`
                              : 'Hold for 1 Second to Unfold Lantern'}
                          </span>
                        </button>
                        {reducedMotion && (
                          <button
                            onClick={() => {
                              setUnfoldProgress(1);
                              soundEngine.playPaperFold();
                            }}
                            className="text-xs underline text-[#e6c487] cursor-pointer"
                          >
                            Instant Unfold (Reduced Motion)
                          </button>
                        )}
                      </>
                    ) : (
                      <button
                        onClick={() => navigateToBeat(2)}
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#f6b94d] text-[#141a29] font-medium text-xs sm:text-sm hover:bg-[#f8c76b] transition cursor-pointer"
                      >
                        <Sparkles className="w-4 h-4" />
                        <span>Lantern Unfolded · Choose Flame Colour</span>
                      </button>
                    )}
                  </div>
                )}

                {/* BEAT 2: CHOOSE ONE OF FOUR FLAME COLOURS (SAME LANTERN) */}
                {currentBeat === 2 && (
                  <div className="w-full space-y-2.5">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {(Object.keys(FLAME_CHOICES) as FlameId[]).map((id) => {
                        const f = FLAME_CHOICES[id];
                        const selected = flameId === id;
                        return (
                          <button
                            key={id}
                            onClick={() => handleSelectFlame(id)}
                            className={`p-2.5 rounded-xl border text-left transition cursor-pointer flex items-center gap-2.5 ${
                              selected
                                ? 'bg-white/15 border-[#f6b94d] shadow-sm'
                                : 'bg-white/5 border-white/10 hover:bg-white/10'
                            }`}
                          >
                            <span
                              className="w-4 h-4 rounded-full flex-shrink-0"
                              style={{
                                backgroundColor: f.primaryHex,
                                boxShadow: `0 0 10px ${f.primaryHex}`
                              }}
                            />
                            <div className="min-w-0">
                              <p className="text-xs font-medium text-white truncate">
                                {f.name}
                              </p>
                              <p className="text-[10px] text-[#c2cede] truncate">
                                {f.subtitle}
                              </p>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                    <div className="flex items-center justify-between text-xs text-[#c7d2e2]">
                      <span>{activeFlame.description}</span>
                      <button
                        onClick={() => navigateToBeat(3)}
                        className="ml-auto flex-shrink-0 inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-[#f6b94d] text-[#141a29] font-medium hover:bg-[#f8c76b] transition cursor-pointer"
                      >
                        <span>Continue</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}

                {/* BEAT 3: TAP TO FOLD PREWRITTEN WISH INTO THE LANTERN */}
                {currentBeat === 3 && (
                  <div className="w-full flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                    <div className="paper-texture rounded-xl p-3 text-[#2a1f15] border border-[#cbb28d] flex-1">
                      <p className="text-[10px] uppercase tracking-widest text-[#7a5835] font-semibold">
                        {PREWRITTEN_WISH.title}
                      </p>
                      <p className="font-story text-base sm:text-lg italic text-[#231910] mt-0.5">
                        “{PREWRITTEN_WISH.text}”
                      </p>
                    </div>

                    {!wishFolded ? (
                      <button
                        onClick={handleFoldWish}
                        className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-medium text-xs sm:text-sm text-[#121826] transition cursor-pointer flex-shrink-0"
                        style={{ backgroundColor: activeFlame.primaryHex }}
                      >
                        <span>Tap to Fold Wish into Lantern</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => navigateToBeat(4)}
                        className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#f6b94d] text-[#141a29] font-medium text-xs sm:text-sm hover:bg-[#f8c76b] transition cursor-pointer flex-shrink-0"
                      >
                        <span>Step onto The Sleeping Street</span>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                )}

                {/* BEAT 4: SCENE 02 — THE SLEEPING STREET (DRAG TO EXPLORE COBBLESTONES & ARCHITECTURE) */}
                {currentBeat === 4 && (
                  <div className="w-full flex flex-wrap items-center justify-between gap-2">
                    <div className="text-xs text-[#d6c7ae] flex items-center gap-2">
                      <Hand className="w-4 h-4 text-[#f6b94d]" />
                      <span>
                        Drag across the Sleeping Street to cast{' '}
                        <strong style={{ color: activeFlame.primaryHex }}>
                          {activeFlame.name.toLowerCase()}
                        </strong>{' '}
                        light over the cobblestones ({Math.min(100, Math.round(streetExploreProgress * 100))}% explored).
                      </span>
                    </div>
                    <button
                      onClick={() => navigateToBeat(5)}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl font-medium text-xs sm:text-sm text-[#121826] transition cursor-pointer"
                      style={{ backgroundColor: activeFlame.primaryHex }}
                    >
                      <span>Approach the Sound Market Arch</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                )}

                {/* BEAT 5: POSTCARD I — A MARKET THAT SELLS ONLY SOUNDS */}
                {currentBeat === 5 && (
                  <div className="w-full flex flex-wrap items-center justify-between gap-2">
                    <button
                      onClick={() => handleLeavePostcard(1)}
                      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-xs sm:text-sm text-[#121826] transition cursor-pointer"
                      style={{ backgroundColor: activeFlame.primaryHex }}
                    >
                      <BookOpen className="w-4 h-4" />
                      <span>
                        {collectedPostcards.includes(1)
                          ? 'Inspect Postcard I: A Market That Sells Only Sounds'
                          : 'Tap to Sketch & Leave Postcard I'}
                      </span>
                    </button>

                    {collectedPostcards.includes(1) && (
                      <button
                        onClick={() => navigateToBeat(6)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs text-white transition cursor-pointer"
                      >
                        <span>Continue to the Water Steps</span>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                )}

                {/* BEAT 6: POSTCARD II — A SEA THAT KEEPS EVERYTHING */}
                {currentBeat === 6 && (
                  <div className="w-full flex flex-wrap items-center justify-between gap-2">
                    <button
                      onClick={() => handleLeavePostcard(2)}
                      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-xs sm:text-sm text-[#121826] transition cursor-pointer"
                      style={{ backgroundColor: activeFlame.primaryHex }}
                    >
                      <BookOpen className="w-4 h-4" />
                      <span>
                        {collectedPostcards.includes(2)
                          ? 'Inspect Postcard II: A Sea That Keeps Everything'
                          : `Tap to Sketch & Leave Postcard II (${Math.min(100, Math.round(waterExploreProgress * 100))}% ripples lit)`}
                      </span>
                    </button>

                    {collectedPostcards.includes(2) && (
                      <button
                        onClick={() => navigateToBeat(7)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs text-white transition cursor-pointer"
                      >
                        <span>Pass Through the Stone Gate</span>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                )}

                {/* BEAT 7: POSTCARD III — A SHOP THAT ONLY STOCKS YESTERDAY */}
                {currentBeat === 7 && (
                  <div className="w-full flex flex-wrap items-center justify-between gap-2">
                    <button
                      onClick={() => handleLeavePostcard(3)}
                      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-xs sm:text-sm text-[#121826] transition cursor-pointer"
                      style={{ backgroundColor: activeFlame.primaryHex }}
                    >
                      <BookOpen className="w-4 h-4" />
                      <span>
                        {collectedPostcards.includes(3)
                          ? 'Inspect Postcard III: A Shop That Only Stocks Yesterday'
                          : 'Tap to Illuminate the Bow Window & Leave Postcard III'}
                      </span>
                    </button>

                    {collectedPostcards.includes(3) && (
                      <button
                        onClick={() => navigateToBeat(8)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs text-white transition cursor-pointer"
                      >
                        <span>Climb to the Unwritten Library</span>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                )}

                {/* BEAT 8: POSTCARD IV — A LIBRARY OF BOOKS NOBODY WROTE */}
                {currentBeat === 8 && (
                  <div className="w-full flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        onPointerDown={startLibraryHold}
                        onPointerUp={stopLanternHold}
                        onPointerLeave={stopLanternHold}
                        onClick={() => handleLeavePostcard(4)}
                        className="no-select-gesture inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-xs sm:text-sm text-[#121826] transition cursor-pointer"
                        style={{ backgroundColor: activeFlame.primaryHex }}
                      >
                        <BookOpen className="w-4 h-4" />
                        <span>
                          {collectedPostcards.includes(4)
                            ? 'Inspect Postcard IV: A Library of Books Nobody Wrote'
                            : 'Hold or Tap to Raise Lantern & Leave Postcard IV'}
                        </span>
                      </button>
                    </div>

                    {collectedPostcards.includes(4) && (
                      <button
                        onClick={() => navigateToBeat(9)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs text-white transition cursor-pointer"
                      >
                        <span>Follow the Lane to Her Street</span>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                )}

                {/* Subtle Previous / Next Beat Stepper */}
                <div className="ml-auto flex items-center gap-1.5">
                  <button
                    onClick={() => navigateToBeat(currentBeat - 1)}
                    disabled={currentBeat <= 1}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 disabled:opacity-30 text-[#d8cfc0] transition cursor-pointer"
                    aria-label="Previous story beat"
                    title="Previous Beat"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => navigateToBeat(currentBeat + 1)}
                    disabled={currentBeat >= 9}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 disabled:opacity-30 text-[#d8cfc0] transition cursor-pointer"
                    aria-label="Next story beat"
                    title="Next Beat"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* ===============================================================
               BEAT 9: ENDING — HER STREET & THE FIXED ENDING TEXT
               =============================================================== */
            <div className="py-2 text-center space-y-4">
              <div className="space-y-1.5 max-w-xl mx-auto font-narrative text-xs sm:text-sm text-[#dfd6c7]">
                {beat.narrativeParagraphs.map((p, idx) => (
                  <p key={idx}>{p}</p>
                ))}
              </div>

              {/* Fixed Ending Lines — Preserved Verbatim */}
              <div
                className="py-4 px-5 rounded-xl border border-[#d4a853]/40 bg-[#0b1324]/85 max-w-md mx-auto space-y-2 shadow-inner"
                style={{
                  boxShadow: `0 0 36px ${activeFlame.primaryHex}22`
                }}
              >
                <p className="font-story text-2xl sm:text-3xl text-[#fbf5e9] tracking-wide">
                  The whole town is yours.
                </p>
                <p
                  className="font-story text-2xl sm:text-3xl font-medium"
                  style={{ color: activeFlame.primaryHex }}
                >
                  Happy Diwali, Anamcara.
                </p>
                <p className="font-narrative text-sm sm:text-base text-[#e3d7c3] tracking-wider pt-1">
                  The lights stay on.
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1">
                <button
                  onClick={() => handleLeavePostcard(5)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl font-medium text-xs sm:text-sm text-[#121826] transition cursor-pointer"
                  style={{ backgroundColor: activeFlame.primaryHex }}
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Read Final Postcard V: Her Street</span>
                </button>

                <button
                  onClick={() => setIsSketchbookOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs text-[#f4ead8] transition cursor-pointer"
                >
                  <span>Browse All 5 Postcards</span>
                </button>

                <button
                  onClick={() => navigateToBeat(1)}
                  className="inline-flex items-center gap-1 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/15 text-xs text-[#b8c5d9] transition cursor-pointer"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  <span>Stroll From Doorstep Again</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </footer>

      {/* =====================================================================
          POSTCARD INSPECTION MODAL
         ===================================================================== */}
      {activePostcardObj && (
        <PostcardModal
          postcard={activePostcardObj}
          flame={activeFlame}
          onClose={() => setActivePostcardId(null)}
          isFinalPostcard={activePostcardObj.id === 5}
          onContinueJourney={
            currentBeat < 9
              ? () => navigateToBeat(Math.min(9, currentBeat + 1))
              : undefined
          }
        />
      )}

      {/* =====================================================================
          TRAVELLER'S SKETCHBOOK & ALL 5 POSTCARDS DRAWER
         ===================================================================== */}
      {isSketchbookOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#050913]/80 backdrop-blur-md animate-fadeIn"
          role="dialog"
          aria-modal="true"
          aria-label="Traveller's Sketchbook and Five Postcards"
        >
          <div className="w-full max-w-3xl rounded-2xl bg-[#10192e] border border-[#d4a853]/35 p-5 sm:p-6 text-[#f4efe6] max-h-[88vh] overflow-y-auto shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <p className="text-[10px] uppercase tracking-[0.2em] text-[#e6c487]">
                  Linen-Bound Sketchbook · Five Places Along the Way
                </p>
                <h3 className="font-story text-2xl sm:text-3xl text-white">
                  Five Postcards for Anamcara
                </h3>
              </div>
              <button
                onClick={() => setIsSketchbookOpen(false)}
                className="px-3 py-1 rounded-full bg-white/10 hover:bg-white/20 text-xs cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {POSTCARDS.map((pc) => {
                const isCollected = collectedPostcards.includes(pc.id);
                return (
                  <div
                    key={pc.id}
                    className="paper-texture rounded-xl p-4 text-[#281e14] border border-[#cbb28d] flex flex-col justify-between space-y-3"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] uppercase tracking-wider font-semibold text-[#7a5835]">
                          {pc.locationLabel}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#2b2015]/10 text-[#4d3822]">
                          {isCollected ? 'Visited' : 'Along the way'}
                        </span>
                      </div>
                      <h4 className="font-story text-xl font-semibold text-[#21170e] mt-1">
                        {pc.title}
                      </h4>
                      <p className="font-narrative italic text-xs text-[#543d26] mt-1">
                        “{pc.frontQuote}”
                      </p>
                    </div>

                    <div className="pt-2 border-t border-[#cbb28d]/70 flex items-center justify-between">
                      <button
                        onClick={() => {
                          setIsSketchbookOpen(false);
                          handleLeavePostcard(pc.id);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-[#2b2015] text-[#f7efe2] text-xs font-medium hover:bg-[#3d2e1f] transition cursor-pointer"
                      >
                        Open Postcard
                      </button>
                      <button
                        onClick={() => {
                          setIsSketchbookOpen(false);
                          navigateToBeat(pc.beatNumber);
                        }}
                        className="text-xs text-[#694d30] underline cursor-pointer"
                      >
                        Visit Scene
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          CREATIVE DIRECTOR STAGE AUDIT & LANTERN VERIFICATION DRAWER
         ===================================================================== */}
{DEV_TOOLS && StageReviewDrawer && (
<Suspense fallback={null}>
      <StageReviewDrawer
        isOpen={isStageDrawerOpen}
        onClose={() => setIsStageDrawerOpen(false)}
        currentBeat={currentBeat}
        onSelectBeat={navigateToBeat}
        environmentOverride={environmentOverride}
        onSetEnvironmentOverride={setEnvironmentOverride}
        flameId={flameId}
        onSelectFlame={handleSelectFlame}
        unfoldProgress={unfoldProgress}
        onSetUnfoldProgress={setUnfoldProgress}
        wishFolded={wishFolded}
        onToggleWishFolded={() => setWishFolded((prev) => !prev)}
        onOpenPostcard={(id) => handleLeavePostcard(id)}
      />
</Suspense>
)}
    </div>
  );
}

export default App;
