import React from 'react';
import { FLAME_CHOICES, FlameId } from '../data/storyData';

interface LanternHeroRigProps {
  flameId: FlameId;
  unfoldProgress: number; // 0 to 1
  wishFolded: boolean;
  isHolding?: boolean;
  showCallouts?: boolean;
  size?: 'compact' | 'normal' | 'large';
}

export const LanternHeroRig: React.FC<LanternHeroRigProps> = ({
  flameId,
  unfoldProgress,
  wishFolded,
  isHolding = false,
  showCallouts = false,
  size = 'normal'
}) => {
  const flame = FLAME_CHOICES[flameId];

  // Calculate vertical unfolding geometry (accordion folded = 62px tall, unfolded = 210px tall)
  const bodyTopY = 195 - unfoldProgress * 128; // from 195 down to 67
  const bodyBottomY = 235;
  const midFoldY = (bodyTopY + bodyBottomY) / 2;
  const foldBulge = (1 - unfoldProgress) * 16;

  const dimensions =
    size === 'compact'
      ? 'w-36 h-44'
      : size === 'large'
      ? 'w-72 h-80 sm:w-80 sm:h-96'
      : 'w-56 h-64 sm:w-64 sm:h-72';

  return (
    <div className={`relative flex items-center justify-center select-none ${dimensions}`}>
      {/* Volumetric Atmospheric Halo Behind Lantern */}
      <div
        className="pointer-events-none absolute rounded-full transition-all duration-700"
        style={{
          width: `${110 + unfoldProgress * 120}px`,
          height: `${110 + unfoldProgress * 120}px`,
          background: `radial-gradient(circle, ${flame.primaryHex}55 0%, ${flame.bounceHex}22 48%, transparent 74%)`,
          filter: 'blur(18px)',
          opacity: 0.25 + unfoldProgress * 0.75,
          transform: isHolding ? 'scale(1.08)' : 'scale(1)'
        }}
      />

      <svg
        viewBox="0 0 320 310"
        className="relative z-10 w-full h-full overflow-visible drop-shadow-[0_18px_28px_rgba(0,0,0,0.65)]"
        role="img"
        aria-label={`Handmade paper and brass lantern (${
          unfoldProgress > 0.9 ? 'unfolded' : 'folded'
        }, ${flame.name} flame)`}
      >
        <defs>
          {/* Handmade Paper Fibre Filter */}
          <filter id="handmade-paper-grain" x="-10%" y="-10%" width="120%" height="120%">
            <feTurbulence
              type="fractalNoise"
              baseFrequency="0.85"
              numOctaves="3"
              seed="14"
              result="noise"
            />
            <feColorMatrix
              type="matrix"
              values="1 0 0 0 0.96  0 1 0 0 0.92  0 0 1 0 0.84  0 0 0 0.09 0"
              in="noise"
              result="coloredNoise"
            />
            <feComposite operator="in" in="coloredNoise" in2="SourceGraphic" result="grain" />
            <feBlend mode="multiply" in="SourceGraphic" in2="grain" />
          </filter>

          {/* Translucent Front Panel Illumination Gradient */}
          <radialGradient id={`panel-glow-${flameId}`} cx="50%" cy="56%" r="58%">
            <stop offset="0%" stopColor={flame.coreHex} stopOpacity={0.35 + unfoldProgress * 0.62} />
            <stop
              offset="45%"
              stopColor={flame.primaryHex}
              stopOpacity={0.28 + unfoldProgress * 0.56}
            />
            <stop offset="85%" stopColor="#e8dac3" stopOpacity="0.92" />
            <stop offset="100%" stopColor="#d4c0a1" stopOpacity="0.96" />
          </radialGradient>

          {/* Translucent Side Panel Illumination Gradient */}
          <radialGradient id={`side-panel-glow-${flameId}`} cx="35%" cy="56%" r="65%">
            <stop
              offset="0%"
              stopColor={flame.primaryHex}
              stopOpacity={0.22 + unfoldProgress * 0.48}
            />
            <stop offset="70%" stopColor="#d9c6a8" stopOpacity="0.88" />
            <stop offset="100%" stopColor="#bda482" stopOpacity="0.94" />
          </radialGradient>

          {/* Fine Brushed Brass Gradient */}
          <linearGradient id="brass-wire-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#9c7332" />
            <stop offset="35%" stopColor="#ecc97e" />
            <stop offset="65%" stopColor="#c99b49" />
            <stop offset="100%" stopColor="#855e23" />
          </linearGradient>

          {/* Bamboo Rib Gradient */}
          <linearGradient id="bamboo-rib-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#b8935c" />
            <stop offset="50%" stopColor="#8f6b39" />
            <stop offset="100%" stopColor="#6b4d24" />
          </linearGradient>
        </defs>

        {/* Natural Wire Suspension Structure (Arched Brass Bail + Top Loop) */}
        <g
          style={{
            transform: `translateY(${(1 - unfoldProgress) * 14}px)`,
            transition: 'transform 120ms ease-out'
          }}
        >
          {/* Top carrying eyelet loop */}
          <circle
            cx="160"
            cy={bodyTopY - 46}
            r="9"
            fill="none"
            stroke="url(#brass-wire-grad)"
            strokeWidth="3"
          />
          {/* Arched natural wire suspension bail */}
          <path
            d={`M 92 ${bodyTopY + 2} Q 112 ${bodyTopY - 42} 160 ${bodyTopY - 38} Q 208 ${
              bodyTopY - 42
            } 228 ${bodyTopY + 2}`}
            fill="none"
            stroke="url(#brass-wire-grad)"
            strokeWidth="2.4"
            strokeLinecap="round"
          />
          {/* Secondary inner suspension wire */}
          <path
            d={`M 116 ${bodyTopY - 6} Q 138 ${bodyTopY - 34} 160 ${bodyTopY - 37} Q 182 ${
              bodyTopY - 34
            } 204 ${bodyTopY - 6}`}
            fill="none"
            stroke="url(#brass-wire-grad)"
            strokeWidth="1.4"
            strokeDasharray="2 1"
            opacity="0.85"
          />
        </g>

        {/* Back/Rear Translucent Paper Edges (visible depth of 4-panel frustum) */}
        <polygon
          points={`114,${bodyTopY - 8} 206,${bodyTopY - 8} 196,${bodyBottomY - 6} 124,${
            bodyBottomY - 6
          }`}
          fill="#c4af8f"
          opacity="0.55"
        />

        {/* LEFT FACETED TAPERED HANDMADE PAPER PANEL */}
        <polygon
          points={`90,${bodyTopY} 132,${bodyTopY + 8} ${135 - foldBulge * 0.5},${midFoldY} 138,${
            bodyBottomY + 6
          } 104,${bodyBottomY - 2} ${96 - foldBulge},${midFoldY}`}
          fill={`url(#side-panel-glow-${flameId})`}
          stroke="#b39366"
          strokeWidth="1.2"
          filter="url(#handmade-paper-grain)"
        />

        {/* RIGHT FACETED TAPERED HANDMADE PAPER PANEL */}
        <polygon
          points={`230,${bodyTopY} 188,${bodyTopY + 8} ${185 + foldBulge * 0.5},${midFoldY} 182,${
            bodyBottomY + 6
          } 216,${bodyBottomY - 2} ${224 + foldBulge},${midFoldY}`}
          fill={`url(#side-panel-glow-${flameId})`}
          stroke="#b39366"
          strokeWidth="1.2"
          filter="url(#handmade-paper-grain)"
        />

        {/* CENTER-FRONT FACETED TAPERED HANDMADE PAPER PANEL */}
        <polygon
          points={`132,${bodyTopY + 8} 188,${bodyTopY + 8} ${186 + foldBulge * 0.4},${midFoldY} 182,${
            bodyBottomY + 6
          } 138,${bodyBottomY + 6} ${134 - foldBulge * 0.4},${midFoldY}`}
          fill={`url(#panel-glow-${flameId})`}
          stroke="#c8a675"
          strokeWidth="1.5"
          filter="url(#handmade-paper-grain)"
        />

        {/* Internal Prewritten Wish Slip (Visible through translucent paper when folded in Beat 3) */}
        {wishFolded && unfoldProgress > 0.5 && (
          <g opacity={0.82}>
            <rect
              x="146"
              y={bodyBottomY - 34}
              width="28"
              height="16"
              rx="2"
              transform={`rotate(-11 160 ${bodyBottomY - 26})`}
              fill="#fff9ed"
              stroke="#c99b49"
              strokeWidth="1"
            />
            <line
              x1="150"
              y1={bodyBottomY - 28}
              x2="168"
              y2={bodyBottomY - 31}
              stroke="#9c7332"
              strokeWidth="1"
              opacity="0.6"
            />
          </g>
        )}

        {/* Internal Flame Core Silhouette */}
        {unfoldProgress > 0.2 && (
          <g
            style={{
              opacity: 0.3 + unfoldProgress * 0.7
            }}
          >
            <ellipse
              cx="160"
              cy={bodyBottomY - 28 * unfoldProgress}
              rx={10 * unfoldProgress}
              ry={18 * unfoldProgress}
              fill={flame.primaryHex}
              opacity="0.55"
            />
            <ellipse
              cx="160"
              cy={bodyBottomY - 26 * unfoldProgress}
              rx={5.5 * unfoldProgress}
              ry={11 * unfoldProgress}
              fill={flame.coreHex}
            />
          </g>
        )}

        {/* APPROVED DIAMOND MOTIF ON HANDMADE PAPER PANELS */}
        {unfoldProgress > 0.28 && (
          <g opacity={Math.min(1, (unfoldProgress - 0.2) * 1.3)}>
            {/* Front Panel Outer Diamond */}
            <polygon
              points={`160,${bodyTopY + 24 * unfoldProgress} 179,${midFoldY + 4} 160,${
                bodyBottomY - 12 * unfoldProgress
              } 141,${midFoldY + 4}`}
              fill="none"
              stroke="#9a723d"
              strokeWidth="1.35"
              opacity="0.68"
            />
            {/* Front Panel Inner Filigree Diamond */}
            <polygon
              points={`160,${bodyTopY + 38 * unfoldProgress} 171,${midFoldY + 4} 160,${
                bodyBottomY - 26 * unfoldProgress
              } 149,${midFoldY + 4}`}
              fill="none"
              stroke="#9a723d"
              strokeWidth="0.9"
              strokeDasharray="2 1.5"
              opacity="0.55"
            />
            {/* Side Panel Left Diamond Motif */}
            <polygon
              points={`112,${bodyTopY + 22 * unfoldProgress} 126,${midFoldY + 2} 118,${
                bodyBottomY - 14 * unfoldProgress
              } 101,${midFoldY}`}
              fill="none"
              stroke="#8c6736"
              strokeWidth="1.1"
              opacity="0.5"
            />
            {/* Side Panel Right Diamond Motif */}
            <polygon
              points={`208,${bodyTopY + 22 * unfoldProgress} 219,${midFoldY} 202,${
                bodyBottomY - 14 * unfoldProgress
              } 194,${midFoldY + 2}`}
              fill="none"
              stroke="#8c6736"
              strokeWidth="1.1"
              opacity="0.5"
            />
          </g>
        )}

        {/* Subtle Handmade Paper Fibres & Fold Crease */}
        <line
          x1={96 - foldBulge}
          y1={midFoldY}
          x2={224 + foldBulge}
          y2={midFoldY}
          stroke="#9e7b4b"
          strokeWidth="1.1"
          strokeDasharray="4 2"
          opacity="0.55"
        />

        {/* DELICATE BAMBOO CORNER RIBS with Node Rings */}
        <g stroke="url(#bamboo-rib-grad)" strokeLinecap="round">
          {/* Outer Left Bamboo Rib */}
          <line x1="90" y1={bodyTopY} x2="104" y2={bodyBottomY - 2} strokeWidth="3.4" />
          {/* Front-Left Bamboo Rib */}
          <line x1="132" y1={bodyTopY + 8} x2="138" y2={bodyBottomY + 6} strokeWidth="3.8" />
          {/* Front-Right Bamboo Rib */}
          <line x1="188" y1={bodyTopY + 8} x2="182" y2={bodyBottomY + 6} strokeWidth="3.8" />
          {/* Outer Right Bamboo Rib */}
          <line x1="230" y1={bodyTopY} x2="216" y2={bodyBottomY - 2} strokeWidth="3.4" />
        </g>

        {/* Bamboo Node Joint Marks */}
        <g stroke="#593d19" strokeWidth="1.6">
          <line x1="94" y1={midFoldY - 4} x2="99" y2={midFoldY - 4} />
          <line x1="133" y1={midFoldY + 2} x2="138" y2={midFoldY + 2} />
          <line x1="182" y1={midFoldY + 2} x2="187" y2={midFoldY + 2} />
          <line x1="221" y1={midFoldY - 4} x2="226" y2={midFoldY - 4} />
        </g>

        {/* FINE BRASS WIRE RINGS (Top Collar & Bottom Collar) */}
        <polygon
          points={`88,${bodyTopY} 132,${bodyTopY + 8} 188,${bodyTopY + 8} 232,${bodyTopY} 206,${
            bodyTopY - 8
          } 114,${bodyTopY - 8}`}
          fill="none"
          stroke="url(#brass-wire-grad)"
          strokeWidth="3.2"
          strokeLinejoin="round"
        />
        <polyline
          points={`102,${bodyBottomY - 2} 138,${bodyBottomY + 6} 182,${bodyBottomY + 6} 218,${
            bodyBottomY - 2
          }`}
          fill="none"
          stroke="url(#brass-wire-grad)"
          strokeWidth="3.6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* SMALL BRASS EYELETS at Corner Junctions */}
        {[
          [94, bodyTopY + 4],
          [134, bodyTopY + 11],
          [186, bodyTopY + 11],
          [226, bodyTopY + 4],
          [106, bodyBottomY - 5],
          [139, bodyBottomY + 2],
          [181, bodyBottomY + 2],
          [214, bodyBottomY - 5]
        ].map(([ex, ey], idx) => (
          <circle
            key={idx}
            cx={ex}
            cy={ey}
            r="3.2"
            fill="#2b1d10"
            stroke="url(#brass-wire-grad)"
            strokeWidth="1.8"
          />
        ))}

        {/* Optional Verification Callouts for Stage 2 Lantern Inspection */}
        {showCallouts && unfoldProgress > 0.8 && (
          <g className="text-[9px] fill-[#f3e6d0]" fontFamily="Inter, sans-serif">
            <line x1="28" y1="42" x2="122" y2={bodyTopY - 28} stroke="#d4a853" strokeWidth="0.9" />
            <text x="10" y="38">Wire suspension</text>

            <line x1="25" y1="88" x2="90" y2={bodyTopY + 2} stroke="#d4a853" strokeWidth="0.9" />
            <text x="8" y="84">Brass ring & eyelets</text>

            <line x1="242" y1="96" x2="188" y2={bodyTopY + 28} stroke="#d4a853" strokeWidth="0.9" />
            <text x="245" y="99">Bamboo corner rib</text>

            <line x1="242" y1="158" x2="176" y2={midFoldY + 4} stroke="#d4a853" strokeWidth="0.9" />
            <text x="245" y="161">Diamond motif & fibres</text>
          </g>
        )}
      </svg>
    </div>
  );
};
