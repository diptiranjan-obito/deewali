import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  EnvironmentBuildId,
  FLAME_CHOICES,
  FlameId,
  STORY_BEATS
} from '../data/storyData';
import {
  createCobblestoneTexture,
  createLanternPaperTexture,
  createPlasterTexture
} from '../utils/proceduralTextures';

interface MiniatureWorldCanvasProps {
  currentBeat: number;
  environmentOverride?: EnvironmentBuildId | null;
  flameId: FlameId;
  unfoldProgress: number; // 0 = folded, 1 = fully unfolded
  wishFolded: boolean;
  collectedPostcards: number[];
  reducedMotion: boolean;
  lanternInspectionMode?: boolean;
  onDragProgress?: (deltaNormalized: number) => void;
}

export const MiniatureWorldCanvas: React.FC<MiniatureWorldCanvasProps> = ({
  currentBeat,
  environmentOverride,
  flameId,
  unfoldProgress,
  wishFolded,
  collectedPostcards,
  reducedMotion,
  lanternInspectionMode = false,
  onDragProgress
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [webglFailed, setWebglFailed] = useState(false);

  // Keep the latest drag callback in a ref so the Three.js scene is NOT torn down
  // and rebuilt whenever the parent re-renders with a new function identity.
  const dragCallbackRef = useRef(onDragProgress);
  useEffect(() => {
    dragCallbackRef.current = onDragProgress;
  }, [onDragProgress]);

  // Mutable state ref for animation loop access without re-creating scene
  const stateRef = useRef({
    currentBeat,
    environmentOverride,
    flameId,
    unfoldProgress,
    wishFolded,
    collectedPostcards,
    reducedMotion,
    lanternInspectionMode,
    dragOffsetX: 0,
    dragOffsetY: 0,
    lanternWalkX: 0
  });

  useEffect(() => {
    stateRef.current.currentBeat = currentBeat;
    stateRef.current.environmentOverride = environmentOverride;
    stateRef.current.flameId = flameId;
    stateRef.current.unfoldProgress = unfoldProgress;
    stateRef.current.wishFolded = wishFolded;
    stateRef.current.collectedPostcards = collectedPostcards;
    stateRef.current.reducedMotion = reducedMotion;
    stateRef.current.lanternInspectionMode = lanternInspectionMode;
  }, [
    currentBeat,
    environmentOverride,
    flameId,
    unfoldProgress,
    wishFolded,
    collectedPostcards,
    reducedMotion,
    lanternInspectionMode
  ]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b1325);
    scene.fog = new THREE.FogExp2(0x111a2e, 0.068);

    const camera = new THREE.PerspectiveCamera(
      38,
      container.clientWidth / Math.max(container.clientHeight, 1),
      0.1,
      60
    );
    camera.position.set(0, 1.85, 5.1);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        powerPreference: 'high-performance'
      });
    } catch {
      setWebglFailed(true);
      return;
    }
    const maxPixelRatio = 2; // unchanged from the original
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, maxPixelRatio));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;

    renderer.domElement.style.touchAction = 'none';
    renderer.domElement.style.display = 'block';
    container.appendChild(renderer.domElement);

    // 2. Shared Procedural Materials (Plaster, Cobblestones, Paper, Brass, Bamboo, Wood)
    const paperTex = createLanternPaperTexture();
    const plasterTex = createPlasterTexture();
    const cobbleTex = createCobblestoneTexture();

    const plasterMat = new THREE.MeshStandardMaterial({
      color: 0x454d63,
      map: plasterTex.map,
      bumpMap: plasterTex.bumpMap,
      bumpScale: 0.035,
      roughness: 0.88,
      metalness: 0.04
    });

    const warmPlasterMat = new THREE.MeshStandardMaterial({
      color: 0x56596b,
      map: plasterTex.map,
      bumpMap: plasterTex.bumpMap,
      bumpScale: 0.04,
      roughness: 0.85,
      metalness: 0.05
    });

    const cobbleMat = new THREE.MeshStandardMaterial({
      color: 0x2a3347,
      map: cobbleTex.map,
      bumpMap: cobbleTex.bumpMap,
      bumpScale: 0.06,
      roughness: 0.42, // Slightly damp blue-hour sheen to catch flame colour speculars
      metalness: 0.12
    });

    const agedWoodMat = new THREE.MeshStandardMaterial({
      color: 0x3b281e,
      roughness: 0.78,
      metalness: 0.06
    });

    const brassMat = new THREE.MeshStandardMaterial({
      color: 0xd4a853,
      roughness: 0.26,
      metalness: 0.86
    });

    const bambooMat = new THREE.MeshStandardMaterial({
      color: 0x9e7b4b,
      roughness: 0.62,
      metalness: 0.08
    });

    const waxyLeafMat = new THREE.MeshStandardMaterial({
      color: 0x1e3f32,
      roughness: 0.32,
      metalness: 0.08
    });

    const windowGlowMat = new THREE.MeshStandardMaterial({
      color: 0xffcfa3,
      emissive: 0xffa952,
      emissiveIntensity: 0.85,
      roughness: 0.3
    });

    // 3. Blue-Hour Atmosphere Lighting
    const ambientLight = new THREE.HemisphereLight(0x3a588a, 0x121824, 0.72);
    scene.add(ambientLight);

    const moonDirLight = new THREE.DirectionalLight(0x7c9cd1, 0.55);
    moonDirLight.position.set(4, 9, 5);
    moonDirLight.castShadow = true;
    moonDirLight.shadow.mapSize.width = 1024;
    moonDirLight.shadow.mapSize.height = 1024;
    scene.add(moonDirLight);

    // 4. APPROVED LANTERN 3D RIG (Central Visual Symbol)
    const lanternGroup = new THREE.Group();
    lanternGroup.position.set(0, 0.68, 1.35);
    scene.add(lanternGroup);

    // Dynamic Lantern Point Light & Bounce Light
    const lanternLight = new THREE.PointLight(0xf6b94d, 3.2, 11, 1.45);
    lanternLight.position.set(0, 0.34, 0);
    // PHASE 1B CANDIDATE (not changed yet): this light sits inside the shadow-casting
    // paper body, so it may shadow itself, and cube shadow maps are costly on phones.
    // Left as originally authored until it can be judged on the live site.
    lanternLight.castShadow = true;
    lanternGroup.add(lanternLight);

    const lanternBounceLight = new THREE.PointLight(0xd9822b, 1.4, 6.5, 1.8);
    lanternBounceLight.position.set(0, -0.1, 0.25);
    lanternGroup.add(lanternBounceLight);

    // Expandable Lantern Body Sub-group (scales vertically for Folded -> Unfolded state)
    const lanternBodyGroup = new THREE.Group();
    lanternGroup.add(lanternBodyGroup);

    // Lower Brass Base Collar & Foot Ring
    const bottomRingGeo = new THREE.TorusGeometry(0.24, 0.012, 12, 4, Math.PI * 2);
    bottomRingGeo.rotateX(Math.PI / 2);
    bottomRingGeo.rotateY(Math.PI / 4);
    const bottomRing = new THREE.Mesh(bottomRingGeo, brassMat);
    bottomRing.position.y = 0.02;
    lanternGroup.add(bottomRing);

    const basePlateGeo = new THREE.CylinderGeometry(0.22, 0.2, 0.03, 4);
    basePlateGeo.rotateY(Math.PI / 4);
    const basePlate = new THREE.Mesh(basePlateGeo, agedWoodMat);
    basePlate.position.y = 0.015;
    lanternGroup.add(basePlate);

    // Faceted, Slightly Tapered 4-Panel Handmade Paper Body
    const lanternPaperMat = new THREE.MeshStandardMaterial({
      color: 0xfbf3e4,
      map: paperTex,
      emissive: 0xf6b94d,
      emissiveMap: paperTex,
      emissiveIntensity: 0.72,
      roughness: 0.65,
      metalness: 0.02,
      transparent: true,
      opacity: 0.93,
      side: THREE.DoubleSide
    });

    // 4-sided tapered frustum (bottom radius 0.23, top radius 0.29, height 0.64)
    const taperedPanelsGeo = new THREE.CylinderGeometry(0.29, 0.23, 0.64, 4, 1, true);
    taperedPanelsGeo.rotateY(Math.PI / 4);
    const taperedPanels = new THREE.Mesh(taperedPanelsGeo, lanternPaperMat);
    taperedPanels.position.y = 0.34;
    taperedPanels.castShadow = true;
    lanternBodyGroup.add(taperedPanels);

    // 4 Delicate Bamboo Corner Ribs + Small Brass Eyelets
    const corners = [
      [1, 1],
      [-1, 1],
      [-1, -1],
      [1, -1]
    ];
    corners.forEach(([cx, cz]) => {
      const botX = cx * 0.165;
      const botZ = cz * 0.165;
      const topX = cx * 0.208;
      const topZ = cz * 0.208;

      const start = new THREE.Vector3(botX, 0.02, botZ);
      const end = new THREE.Vector3(topX, 0.66, topZ);
      const dir = new THREE.Vector3().subVectors(end, start);
      const len = dir.length();

      const ribGeo = new THREE.CylinderGeometry(0.01, 0.012, len, 8);
      const rib = new THREE.Mesh(ribGeo, bambooMat);
      rib.position.copy(start).add(end).multiplyScalar(0.5);
      rib.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
      lanternBodyGroup.add(rib);

      // Bamboo node ring halfway up the rib
      const nodeGeo = new THREE.TorusGeometry(0.013, 0.003, 6, 12);
      nodeGeo.rotateX(Math.PI / 2);
      const nodeMesh = new THREE.Mesh(nodeGeo, bambooMat);
      nodeMesh.position.copy(rib.position);
      lanternBodyGroup.add(nodeMesh);

      // Small Brass Eyelets (top and bottom of each panel corner)
      const eyeletGeo = new THREE.TorusGeometry(0.016, 0.0045, 8, 16);
      const topEyelet = new THREE.Mesh(eyeletGeo, brassMat);
      topEyelet.position.set(topX * 0.96, 0.63, topZ * 0.96);
      topEyelet.lookAt(0, 0.63, 0);
      lanternBodyGroup.add(topEyelet);

      const botEyelet = new THREE.Mesh(eyeletGeo, brassMat);
      botEyelet.position.set(botX * 0.96, 0.05, botZ * 0.96);
      botEyelet.lookAt(0, 0.05, 0);
      lanternBodyGroup.add(botEyelet);
    });

    // Upper Fine Brass Wire Ring
    const topRingGeo = new THREE.TorusGeometry(0.3, 0.012, 12, 4, Math.PI * 2);
    topRingGeo.rotateX(Math.PI / 2);
    topRingGeo.rotateY(Math.PI / 4);
    const topRing = new THREE.Mesh(topRingGeo, brassMat);
    topRing.position.y = 0.66;
    lanternBodyGroup.add(topRing);

    // Fine Horizontal Middle Brass Wire Support
    const midWireGeo = new THREE.TorusGeometry(0.265, 0.005, 8, 4, Math.PI * 2);
    midWireGeo.rotateX(Math.PI / 2);
    midWireGeo.rotateY(Math.PI / 4);
    const midWire = new THREE.Mesh(midWireGeo, brassMat);
    midWire.position.y = 0.34;
    lanternBodyGroup.add(midWire);

    // Natural Wire Suspension Bail / Arch
    const bailCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.205, 0.66, -0.205),
      new THREE.Vector3(-0.14, 0.86, -0.14),
      new THREE.Vector3(0, 0.94, 0),
      new THREE.Vector3(0.14, 0.86, 0.14),
      new THREE.Vector3(0.205, 0.66, 0.205)
    ]);
    const bailGeo = new THREE.TubeGeometry(bailCurve, 24, 0.006, 8, false);
    const bailMesh = new THREE.Mesh(bailGeo, brassMat);
    lanternBodyGroup.add(bailMesh);

    // Top suspension eyelet loop
    const loopGeo = new THREE.TorusGeometry(0.028, 0.006, 8, 20);
    const loopMesh = new THREE.Mesh(loopGeo, brassMat);
    loopMesh.position.set(0, 0.96, 0);
    lanternBodyGroup.add(loopMesh);

    // Internal Flame Core & Halo
    const flameCoreMat = new THREE.MeshBasicMaterial({
      color: 0xfff7df
    });
    const flameCoreGeo = new THREE.SphereGeometry(0.055, 16, 16);
    flameCoreGeo.scale(0.8, 1.45, 0.8);
    const flameCore = new THREE.Mesh(flameCoreGeo, flameCoreMat);
    flameCore.position.y = 0.24;
    lanternBodyGroup.add(flameCore);

    // Folded Prewritten Wish Slip inside Lantern Cradle
    const wishSlipGeo = new THREE.BoxGeometry(0.16, 0.09, 0.015);
    const wishSlipMat = new THREE.MeshStandardMaterial({
      color: 0xf9f1e2,
      roughness: 0.7
    });
    const wishSlipMesh = new THREE.Mesh(wishSlipGeo, wishSlipMat);
    wishSlipMesh.position.set(0.05, 0.12, 0.04);
    wishSlipMesh.rotation.set(0.35, 0.5, 0.18);
    wishSlipMesh.visible = false;
    lanternBodyGroup.add(wishSlipMesh);

    // ========================================================================
    // 5. FOUR ENVIRONMENTAL BUILDS
    // ========================================================================

    // --- BUILD 01: THE WEATHERED DOORSTEP ---
    const doorstepGroup = new THREE.Group();
    scene.add(doorstepGroup);

    // Threshold Cobblestone Ground & Stepped Stone Plinth
    const groundStep0 = new THREE.Mesh(new THREE.BoxGeometry(6.5, 0.25, 4.5), cobbleMat);
    groundStep0.position.set(0, -0.12, 1.0);
    groundStep0.receiveShadow = true;
    doorstepGroup.add(groundStep0);

    const step1 = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.28, 2.2), warmPlasterMat);
    step1.position.set(0, 0.14, 0.7);
    step1.receiveShadow = true;
    doorstepGroup.add(step1);

    const step2 = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.28, 1.45), warmPlasterMat);
    step2.position.set(0, 0.42, 0.25);
    step2.receiveShadow = true;
    doorstepGroup.add(step2);

    // Weathered Plaster Wall & Aged Wooden Doorway
    const doorstepWall = new THREE.Mesh(new THREE.BoxGeometry(5.8, 4.2, 0.45), plasterMat);
    doorstepWall.position.set(0, 2.1, -0.35);
    doorstepWall.receiveShadow = true;
    doorstepGroup.add(doorstepWall);

    const doorFrame = new THREE.Mesh(new THREE.BoxGeometry(1.75, 2.65, 0.52), agedWoodMat);
    doorFrame.position.set(0, 1.75, -0.32);
    doorstepGroup.add(doorFrame);

    const doorPanel = new THREE.Mesh(
      new THREE.BoxGeometry(1.42, 2.4, 0.48),
      new THREE.MeshStandardMaterial({ color: 0x2c1d14, roughness: 0.75 })
    );
    doorPanel.position.set(0, 1.7, -0.28);
    doorstepGroup.add(doorPanel);

    // Brass Door Ring & Hanging Temple Bell
    const knocker = new THREE.Mesh(new THREE.TorusGeometry(0.06, 0.012, 8, 18), brassMat);
    knocker.position.set(0.32, 1.62, -0.02);
    doorstepGroup.add(knocker);

    // Traveller's Sketchbook resting on the doorstep stone
    const sketchbookCover = new THREE.Mesh(
      new THREE.BoxGeometry(0.56, 0.06, 0.42),
      new THREE.MeshStandardMaterial({ color: 0x5c3d2e, roughness: 0.82 })
    );
    sketchbookCover.position.set(-0.78, 0.59, 0.48);
    sketchbookCover.rotation.y = 0.28;
    doorstepGroup.add(sketchbookCover);

    const sketchbookPages = new THREE.Mesh(
      new THREE.BoxGeometry(0.52, 0.05, 0.39),
      new THREE.MeshStandardMaterial({ color: 0xf4ead5, roughness: 0.7 })
    );
    sketchbookPages.position.set(-0.78, 0.61, 0.48);
    sketchbookPages.rotation.y = 0.28;
    doorstepGroup.add(sketchbookPages);

    // Terracotta Pots & Waxy Foliage on Doorstep
    const potMat = new THREE.MeshStandardMaterial({ color: 0x8c4a32, roughness: 0.78 });
    [-1.35, 1.35].forEach((px, idx) => {
      const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.17, 0.36, 12), potMat);
      pot.position.set(px, 0.46, 0.55);
      doorstepGroup.add(pot);

      for (let l = 0; l < 5; l++) {
        const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 8), waxyLeafMat);
        leaf.scale.set(1.2, 0.45, 0.8);
        leaf.position.set(
          px + Math.cos(l * 1.25) * 0.14,
          0.68 + (l % 2) * 0.06,
          0.55 + Math.sin(l * 1.25) * 0.14
        );
        doorstepGroup.add(leaf);
      }

      // Waxy marigold / jasmine buds
      const bud = new THREE.Mesh(
        new THREE.SphereGeometry(0.05, 8, 8),
        new THREE.MeshStandardMaterial({
          color: idx === 0 ? 0xf5a623 : 0xfaf6eb,
          roughness: 0.4
        })
      );
      bud.position.set(px, 0.76, 0.58);
      doorstepGroup.add(bud);
    });

    // --- BUILD 02: SCENE 02 — THE SLEEPING STREET ---
    const sleepingStreetGroup = new THREE.Group();
    sleepingStreetGroup.visible = false;
    scene.add(sleepingStreetGroup);

    // Long Uneven Cobblestone Lane curving into depth
    const streetRoad = new THREE.Mesh(new THREE.BoxGeometry(7.2, 0.3, 14.5), cobbleMat);
    streetRoad.position.set(0, -0.15, -2.5);
    streetRoad.receiveShadow = true;
    sleepingStreetGroup.add(streetRoad);

    // Raised stone sidewalks on both sides
    [-2.45, 2.45].forEach((sx) => {
      const curb = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.28, 14.0), warmPlasterMat);
      curb.position.set(sx, 0.12, -2.5);
      curb.receiveShadow = true;
      sleepingStreetGroup.add(curb);
    });

    // Miniature Town Row-Houses Left & Right with Old Architecture, Warm Windows, Timber Eaves
    const houseConfigs = [
      { x: -2.55, z: 0.8, w: 1.9, h: 3.6, d: 2.3, winY: 2.2 },
      { x: -2.65, z: -1.7, w: 2.0, h: 4.3, d: 2.5, winY: 2.6 },
      { x: -2.5, z: -4.3, w: 1.9, h: 3.8, d: 2.4, winY: 2.3 },
      { x: 2.55, z: 0.5, w: 1.9, h: 3.9, d: 2.4, winY: 2.4 },
      { x: 2.6, z: -2.0, w: 2.1, h: 4.5, d: 2.5, winY: 2.75 },
      { x: 2.48, z: -4.5, w: 1.9, h: 3.7, d: 2.3, winY: 2.2 }
    ];

    houseConfigs.forEach((hc, idx) => {
      const houseMesh = new THREE.Mesh(
        new THREE.BoxGeometry(hc.w, hc.h, hc.d),
        idx % 2 === 0 ? plasterMat : warmPlasterMat
      );
      houseMesh.position.set(hc.x, hc.h / 2 + 0.2, hc.z);
      houseMesh.castShadow = true;
      houseMesh.receiveShadow = true;
      sleepingStreetGroup.add(houseMesh);

      // Overhanging carved wooden eaves / balcony
      const signX = hc.x < 0 ? 1 : -1;
      const balcony = new THREE.Mesh(
        new THREE.BoxGeometry(0.42, 0.18, hc.d * 0.78),
        agedWoodMat
      );
      balcony.position.set(hc.x + signX * (hc.w / 2 + 0.12), hc.winY - 0.42, hc.z);
      sleepingStreetGroup.add(balcony);

      // Warm lit upper window with wooden shutters
      const winMesh = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.62, 0.46), windowGlowMat);
      winMesh.position.set(hc.x + signX * (hc.w / 2 + 0.02), hc.winY, hc.z);
      sleepingStreetGroup.add(winMesh);

      // Doorstep pot & waxy foliage along the sleeping street
      const streetPot = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.12, 0.25, 10), potMat);
      streetPot.position.set(hc.x + signX * (hc.w / 2 + 0.28), 0.38, hc.z + 0.55);
      sleepingStreetGroup.add(streetPot);

      const streetFoliage = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 8), waxyLeafMat);
      streetFoliage.position.set(hc.x + signX * (hc.w / 2 + 0.28), 0.56, hc.z + 0.55);
      sleepingStreetGroup.add(streetFoliage);
    });

    // Old Stone Archway at the end of the Sleeping Street (Sound Market Threshold)
    const archPillarL = new THREE.Mesh(new THREE.BoxGeometry(1.1, 3.8, 1.1), plasterMat);
    archPillarL.position.set(-1.65, 1.9, -5.8);
    sleepingStreetGroup.add(archPillarL);

    const archPillarR = new THREE.Mesh(new THREE.BoxGeometry(1.1, 3.8, 1.1), plasterMat);
    archPillarR.position.set(1.65, 1.9, -5.8);
    sleepingStreetGroup.add(archPillarR);

    const archBeam = new THREE.Mesh(new THREE.BoxGeometry(4.6, 0.95, 1.25), warmPlasterMat);
    archBeam.position.set(0, 3.9, -5.8);
    sleepingStreetGroup.add(archBeam);

    // Sound Market Stall under the Archway (Woven cloth awning + glass sound jars)
    const awningMat = new THREE.MeshStandardMaterial({
      color: 0x8f4e3b,
      roughness: 0.85,
      side: THREE.DoubleSide
    });
    const soundAwning = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.08, 1.5), awningMat);
    soundAwning.position.set(-0.6, 2.35, -4.4);
    soundAwning.rotation.z = -0.12;
    sleepingStreetGroup.add(soundAwning);

    const stallTable = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.75, 0.9), agedWoodMat);
    stallTable.position.set(-0.7, 0.62, -4.5);
    sleepingStreetGroup.add(stallTable);

    // Glass jars of preserved sounds glowing softly on the stall table
    const glassJarMat = new THREE.MeshStandardMaterial({
      color: 0xd8f0ff,
      emissive: 0xf6b94d,
      emissiveIntensity: 0.45,
      roughness: 0.15,
      metalness: 0.1,
      transparent: true,
      opacity: 0.78
    });
    for (let j = 0; j < 5; j++) {
      const jar = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.22, 12), glassJarMat);
      jar.position.set(-1.3 + j * 0.28, 1.12, -4.45 + (j % 2) * 0.15);
      sleepingStreetGroup.add(jar);
    }

    // --- BUILD 03: THE WATER STEPS ("A sea that keeps everything") ---
    const waterGroup = new THREE.Group();
    waterGroup.visible = false;
    scene.add(waterGroup);

    // Stepped stone ghat descending into the harbour basin
    for (let s = 0; s < 5; s++) {
      const ghatStep = new THREE.Mesh(
        new THREE.BoxGeometry(7.2, 0.28, 1.15),
        s % 2 === 0 ? warmPlasterMat : plasterMat
      );
      ghatStep.position.set(0, 0.85 - s * 0.24, 2.1 - s * 0.85);
      ghatStep.receiveShadow = true;
      waterGroup.add(ghatStep);
    }

    // Reflective Water Surface
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x0e1e38,
      emissive: 0x1a2e4c,
      emissiveIntensity: 0.25,
      roughness: 0.14,
      metalness: 0.78
    });
    const waterPlane = new THREE.Mesh(new THREE.PlaneGeometry(14, 12, 32, 32), waterMat);
    waterPlane.rotation.x = -Math.PI / 2;
    waterPlane.position.set(0, -0.18, -3.6);
    waterPlane.receiveShadow = true;
    waterGroup.add(waterPlane);

    // Stone Balustrade Posts & Brass Mooring Rings
    [-1.8, 1.8].forEach((bx) => {
      const bollard = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.26, 0.95, 12), plasterMat);
      bollard.position.set(bx, 0.62, -0.4);
      waterGroup.add(bollard);

      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.08, 0.015, 8, 16), brassMat);
      ring.position.set(bx, 0.72, -0.16);
      waterGroup.add(ring);
    });

    // Floating Wax-Paper Boats & Submerged Glowing Memories
    const paperBoats: THREE.Mesh[] = [];
    const boatPositions = [
      [-1.1, -1.9],
      [0.65, -2.4],
      [-0.35, -3.5],
      [1.4, -3.9]
    ];
    boatPositions.forEach(([bx, bz]) => {
      const boat = new THREE.Mesh(
        new THREE.ConeGeometry(0.16, 0.14, 4),
        new THREE.MeshStandardMaterial({
          color: 0xf7efe0,
          emissive: 0xf6b94d,
          emissiveIntensity: 0.35,
          roughness: 0.5
        })
      );
      boat.rotation.x = Math.PI;
      boat.position.set(bx, -0.14, bz);
      waterGroup.add(boat);
      paperBoats.push(boat);
    });

    // --- BUILD 04: MARKET THROUGH GATE, YESTERDAY SHOP, LIBRARY & HER STREET ---
    const marketGateGroup = new THREE.Group();
    marketGateGroup.visible = false;
    scene.add(marketGateGroup);

    const courtyardGround = new THREE.Mesh(new THREE.BoxGeometry(9.0, 0.3, 12.0), cobbleMat);
    courtyardGround.position.set(0, -0.15, -1.8);
    courtyardGround.receiveShadow = true;
    marketGateGroup.add(courtyardGround);

    // Left: "A Shop That Only Stocks Yesterday" (Bow-windowed curiosity shop)
    const shopBuilding = new THREE.Mesh(new THREE.BoxGeometry(2.6, 3.6, 3.2), warmPlasterMat);
    shopBuilding.position.set(-2.35, 1.8, -1.9);
    marketGateGroup.add(shopBuilding);

    const bowWindowFrame = new THREE.Mesh(new THREE.BoxGeometry(0.55, 1.45, 1.65), agedWoodMat);
    bowWindowFrame.position.set(-1.0, 1.25, -1.8);
    marketGateGroup.add(bowWindowFrame);

    const bowWindowGlass = new THREE.Mesh(new THREE.BoxGeometry(0.45, 1.18, 1.45), windowGlowMat);
    bowWindowGlass.position.set(-0.92, 1.25, -1.8);
    marketGateGroup.add(bowWindowGlass);

    // Right Upper: "A Library of Books Nobody Wrote" (Timber Gallery & Brass Lectern)
    const libraryBase = new THREE.Mesh(new THREE.BoxGeometry(2.6, 2.1, 3.4), plasterMat);
    libraryBase.position.set(2.35, 1.05, -2.0);
    marketGateGroup.add(libraryBase);

    const libraryGallery = new THREE.Mesh(new THREE.BoxGeometry(2.5, 1.9, 3.2), agedWoodMat);
    libraryGallery.position.set(2.3, 2.95, -2.0);
    marketGateGroup.add(libraryGallery);

    // Brass Reading Lectern in the Upper Library Alcove
    const lecternStand = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.12, 0.75, 10), brassMat);
    lecternStand.position.set(1.15, 2.35, -1.65);
    marketGateGroup.add(lecternStand);

    const lecternBook = new THREE.Mesh(
      new THREE.BoxGeometry(0.38, 0.06, 0.28),
      new THREE.MeshStandardMaterial({
        color: 0xf7efe0,
        emissive: 0xf6b94d,
        emissiveIntensity: 0.4
      })
    );
    lecternBook.position.set(1.15, 2.75, -1.65);
    lecternBook.rotation.z = 0.35;
    marketGateGroup.add(lecternBook);

    // Center-Back: Her Street Window Ledge & Warm Lit Town Silhouette
    const herStreetHouse = new THREE.Mesh(new THREE.BoxGeometry(3.4, 4.1, 2.2), warmPlasterMat);
    herStreetHouse.position.set(0, 2.05, -4.6);
    marketGateGroup.add(herStreetHouse);

    const herWindowLedge = new THREE.Mesh(new THREE.BoxGeometry(1.75, 0.18, 0.65), plasterMat);
    herWindowLedge.position.set(0, 1.18, -3.35);
    marketGateGroup.add(herWindowLedge);

    const herWarmWindow = new THREE.Mesh(new THREE.BoxGeometry(1.25, 1.45, 0.12), windowGlowMat);
    herWarmWindow.position.set(0, 2.0, -3.48);
    marketGateGroup.add(herWarmWindow);

    // 5 Miniature Postcard Beacons placed in the world as they are collected
    const postcardMeshes: THREE.Mesh[] = [];
    const postcardPositions: [number, number, number][] = [
      [-0.55, 1.03, -4.2], // Postcard 1: Sound Market
      [0.85, 0.92, 0.85],  // Postcard 2: Water Ghat
      [-0.78, 0.68, -1.2], // Postcard 3: Yesterday Shop
      [1.15, 2.81, -1.55], // Postcard 4: Unwritten Library
      [-0.38, 1.3, -3.22]  // Postcard 5: Her Street Window Sill
    ];
    postcardPositions.forEach(([px, py, pz]) => {
      const cardMesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.32, 0.025, 0.22),
        new THREE.MeshStandardMaterial({
          color: 0xfbf3e4,
          emissive: 0xf6b94d,
          emissiveIntensity: 0.38,
          roughness: 0.6
        })
      );
      cardMesh.position.set(px, py, pz);
      cardMesh.rotation.y = 0.24;
      cardMesh.visible = false;
      scene.add(cardMesh);
      postcardMeshes.push(cardMesh);
    });

    // 6. Subtle Mist & Floating Fireflies
    const fireflyCount = 46;
    const fireflyGeo = new THREE.BufferGeometry();
    const fireflyPositions = new Float32Array(fireflyCount * 3);
    for (let i = 0; i < fireflyCount; i++) {
      fireflyPositions[i * 3] = (Math.random() - 0.5) * 9;
      fireflyPositions[i * 3 + 1] = 0.3 + Math.random() * 3.5;
      fireflyPositions[i * 3 + 2] = (Math.random() - 0.5) * 10 - 1;
    }
    fireflyGeo.setAttribute('position', new THREE.BufferAttribute(fireflyPositions, 3));
    const fireflyMat = new THREE.PointsMaterial({
      color: 0xf6b94d,
      size: 0.09,
      transparent: true,
      opacity: 0.78
    });
    const fireflies = new THREE.Points(fireflyGeo, fireflyMat);
    scene.add(fireflies);

    // 7. Pointer / Touch Drag Interaction for Camera Parallax & Lantern Guidance
    let isPointerDown = false;
    let lastX = 0;
    let lastY = 0;

    const handlePointerDown = (e: PointerEvent) => {
      isPointerDown = true;
      lastX = e.clientX;
      lastY = e.clientY;
    };

    const handlePointerMove = (e: PointerEvent) => {
      if (!isPointerDown) return;
      const dx = e.clientX - lastX;
      const dy = e.clientY - lastY;
      lastX = e.clientX;
      lastY = e.clientY;

      stateRef.current.dragOffsetX = Math.max(
        -1.5,
        Math.min(1.5, stateRef.current.dragOffsetX + dx * 0.005)
      );
      stateRef.current.dragOffsetY = Math.max(
        -0.7,
        Math.min(0.7, stateRef.current.dragOffsetY - dy * 0.004)
      );
      stateRef.current.lanternWalkX = Math.max(
        -1.1,
        Math.min(1.1, stateRef.current.lanternWalkX + dx * 0.004)
      );

      if (Math.abs(dx) + Math.abs(dy) > 2) {
        dragCallbackRef.current?.((Math.abs(dx) + Math.abs(dy)) * 0.0045);
      }
    };

    const handlePointerUp = () => {
      isPointerDown = false;
    };

    const domElem = renderer.domElement;
    domElem.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);
    window.addEventListener('pointercancel', handlePointerUp);

    // 8. Responsive Resize Handler
    const handleResize = () => {
      const w = container.clientWidth;
      const h = Math.max(container.clientHeight, 1);
      if (w === 0) return;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, maxPixelRatio));
      renderer.setSize(w, h);
    };
    const resizeObserver =
      typeof ResizeObserver !== 'undefined' ? new ResizeObserver(handleResize) : null;
    resizeObserver?.observe(container);
    window.addEventListener('resize', handleResize);

    const handleContextLost = (e: Event) => e.preventDefault();
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);

    // 9. Animation Loop
    let animId = 0;
    const clock = new THREE.Clock();
    const targetCamPos = new THREE.Vector3();
    const currentLookAt = new THREE.Vector3(0, 1.0, 0);
    const targetLookAt = new THREE.Vector3(0, 1.0, 0);
    const tmpLight = new THREE.Color();
    const tmpBounce = new THREE.Color();
    const tmpFog = new THREE.Color();
    const tmpCore = new THREE.Color();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();
      const st = stateRef.current;

      const beatObj =
        STORY_BEATS.find((b) => b.beatNumber === st.currentBeat) || STORY_BEATS[0];
      const activeEnv: EnvironmentBuildId =
        st.environmentOverride || beatObj.environmentBuild;

      // Toggle visible environmental build
      doorstepGroup.visible = activeEnv === 'doorstep';
      sleepingStreetGroup.visible = activeEnv === 'sleeping-street';
      waterGroup.visible = activeEnv === 'water';
      marketGateGroup.visible = activeEnv === 'market-gate';

      // Show collected postcards in the miniature world
      postcardMeshes.forEach((mesh, idx) => {
        mesh.visible = st.collectedPostcards.includes(idx + 1);
      });

      // Apply selected Flame Colour to Lantern, Surrounds, Reflections & Atmosphere
      const flameCfg = FLAME_CHOICES[st.flameId];
      const targetLightColor = tmpLight.set(flameCfg.threeLightColor);
      const targetBounceColor = tmpBounce.set(flameCfg.threeBounceColor);
      const targetFogColor = tmpFog.set(flameCfg.threeFogColor);

      lanternLight.color.lerp(targetLightColor, 0.08);
      lanternBounceLight.color.lerp(targetBounceColor, 0.08);
      lanternPaperMat.emissive.lerp(targetLightColor, 0.08);
      flameCoreMat.color.lerp(tmpCore.set(flameCfg.coreHex), 0.1);
      fireflyMat.color.lerp(targetLightColor, 0.08);
      waterMat.emissive.lerp(targetBounceColor, 0.06);
      if (scene.fog instanceof THREE.FogExp2) {
        scene.fog.color.lerp(targetFogColor, 0.05);
      }

      // Folded vs Unfolded Lantern Geometry State (0 -> 1)
      const foldScaleY = 0.18 + st.unfoldProgress * 0.82;
      lanternBodyGroup.scale.set(1, foldScaleY, 1);

      // Lantern Internal Illumination scales with unfold progress
      const flicker = st.reducedMotion
        ? 0
        : Math.sin(elapsed * 7.5) * 0.08 + Math.cos(elapsed * 13.2) * 0.04;
      const baseIntensity = 0.25 + st.unfoldProgress * 3.15;
      lanternLight.intensity = baseIntensity + flicker;
      lanternBounceLight.intensity = (0.1 + st.unfoldProgress * 1.45) + flicker * 0.4;
      lanternPaperMat.emissiveIntensity = 0.15 + st.unfoldProgress * 0.72 + flicker * 0.1;

      // Wish slip inside lantern
      wishSlipMesh.visible = st.wishFolded && st.unfoldProgress > 0.6;

      // Position the SAME Lantern naturally across the scenes
      const gentleBob = st.reducedMotion ? 0 : Math.sin(elapsed * 1.8) * 0.035;
      if (st.lanternInspectionMode) {
        lanternGroup.position.set(0, 0.88 + gentleBob * 0.4, 2.35);
        lanternGroup.rotation.y = elapsed * (st.reducedMotion ? 0 : 0.45) + st.dragOffsetX;
      } else if (activeEnv === 'doorstep') {
        lanternGroup.position.set(0.32 + st.lanternWalkX * 0.25, 0.56, 0.35);
        lanternGroup.rotation.y = 0.32 + st.dragOffsetX * 0.4;
      } else if (activeEnv === 'sleeping-street') {
        const zPos = st.currentBeat === 5 ? -2.9 : 0.4;
        lanternGroup.position.set(
          st.lanternWalkX * 0.85,
          0.95 + gentleBob,
          zPos
        );
        lanternGroup.rotation.y = st.dragOffsetX * 0.5 + (st. reducedMotion ? 0 : Math.sin(elapsed * 1.1) * 0.08);
      } else if (activeEnv === 'water') {
        lanternGroup.position.set(
          0.25 + st.lanternWalkX * 0.95,
          0.68 + gentleBob,
          -0.55
        );
        lanternGroup.rotation.y = st.dragOffsetX * 0.4;
      } else {
        // market-gate & Her Street finale
        if (st.currentBeat === 7) {
          lanternGroup.position.set(-0.45 + st.lanternWalkX * 0.35, 1.15 + gentleBob, -1.2);
        } else if (st.currentBeat === 8) {
          lanternGroup.position.set(0.85, 2.45 + gentleBob, -1.35);
        } else {
          // Beat 9: Resting warmly on Her Street window ledge
          lanternGroup.position.set(0.28, 1.27, -3.22);
        }
        lanternGroup.rotation.y = 0.25 + st.dragOffsetX * 0.35;
      }

      // Camera target & smooth cinematic movement
      if (st.lanternInspectionMode) {
        targetCamPos.set(0, 1.32, 4.1);
        targetLookAt.set(0, 1.18, 2.35);
      } else if (st.environmentOverride === 'sleeping-street' && beatObj.environmentBuild !== 'sleeping-street') {
        targetCamPos.set(0.2, 2.15, 7.2);
        targetLookAt.set(0, 1.25, -1.8);
      } else {
        const [cx, cy, cz] = beatObj.cameraPreset.position;
        const [tx, ty, tz] = beatObj.cameraPreset.target;
        const driftX = st.reducedMotion ? 0 : Math.sin(elapsed * 0.42) * 0.14;
        const driftY = st.reducedMotion ? 0 : Math.cos(elapsed * 0.35) * 0.06;
        targetCamPos.set(
          cx + driftX + st.dragOffsetX * 0.65,
          cy + driftY + st.dragOffsetY * 0.45,
          cz
        );
        targetLookAt.set(tx + st.dragOffsetX * 0.25, ty + st.dragOffsetY * 0.2, tz);
      }

      camera.position.lerp(targetCamPos, 0.05);
      currentLookAt.lerp(targetLookAt, 0.06);
      camera.lookAt(currentLookAt);

      // Gentle firefly drift & paper boat bobbing
      if (!st.reducedMotion) {
        const posAttr = fireflyGeo.getAttribute('position') as THREE.BufferAttribute;
        for (let i = 0; i < fireflyCount; i++) {
          const y = posAttr.getY(i) + Math.sin(elapsed * 1.4 + i) * 0.0025;
          posAttr.setY(i, y);
        }
        posAttr.needsUpdate = true;

        paperBoats.forEach((boat, idx) => {
          boat.position.y = -0.14 + Math.sin(elapsed * 2.0 + idx * 1.3) * 0.015;
          boat.rotation.z = Math.sin(elapsed * 1.5 + idx) * 0.05;
        });
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animId);
      domElem.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      window.removeEventListener('pointercancel', handlePointerUp);
      window.removeEventListener('resize', handleResize);
      resizeObserver?.disconnect();
      domElem.removeEventListener('webglcontextlost', handleContextLost);

      // Dispose every GPU resource the scene created.
      const disposedTextures = new Set<THREE.Texture>();
      const disposeMaterial = (m: THREE.Material) => {
        Object.values(m).forEach((v) => {
          if (v instanceof THREE.Texture && !disposedTextures.has(v)) {
            disposedTextures.add(v);
            v.dispose();
          }
        });
        m.dispose();
      };
      scene.traverse((obj) => {
        const o = obj as THREE.Mesh | THREE.Points;
        if (o.geometry) o.geometry.dispose();
        const mat = o.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(mat)) mat.forEach(disposeMaterial);
        else if (mat) disposeMaterial(mat);
      });
      [paperTex, plasterTex.map, plasterTex.bumpMap, cobbleTex.map, cobbleTex.bumpMap].forEach(
        (t) => t.dispose()
      );

      renderer.dispose();
      renderer.forceContextLoss();
      if (domElem.parentElement === container) container.removeChild(domElem);
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="relative w-full h-full no-select-gesture cursor-grab active:cursor-grabbing"
      aria-label="Interactive 3D Storybook Miniature World"
      style={{ touchAction: 'none' }}
    >
      {webglFailed && (
        <div className="absolute inset-0 flex items-center justify-center p-8 text-center text-sm text-[#cbb894]">
          This device could not start the 3D scene. The story text below still works.
        </div>
      )}
    </div>
  );
};
