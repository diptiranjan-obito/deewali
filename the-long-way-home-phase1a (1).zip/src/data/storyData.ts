export type FlameId = 'honey-gold' | 'almost-white' | 'deep-rose' | 'green-gold';

export type EnvironmentBuildId = 'doorstep' | 'sleeping-street' | 'water' | 'market-gate';

export type GestureType = 'hold' | 'tap' | 'drag';

export interface FlameConfig {
  id: FlameId;
  name: string;
  subtitle: string;
  primaryHex: string;
  coreHex: string;
  paperTintHex: string;
  bounceHex: string;
  waterReflectionHex: string;
  cobbleSpecularHex: string;
  fogHex: string;
  threeLightColor: number;
  threeBounceColor: number;
  threeFogColor: number;
  description: string;
}

export interface PostcardData {
  id: number;
  beatNumber: number;
  slug: string;
  title: string;
  locationLabel: string;
  environmentBuild: EnvironmentBuildId;
  stampLabel: string;
  sketchCaption: string;
  frontQuote: string;
  backGreeting: string;
  backBody: string[];
  backSignoff: string;
  memoryArtifact: string;
  materialNotes: string;
}

export interface StoryBeat {
  beatNumber: number;
  id: string;
  title: string;
  subtitle: string;
  environmentBuild: EnvironmentBuildId;
  environmentLabel: string;
  gesture: GestureType;
  gestureInstruction: string;
  narrativeParagraphs: string[];
  sketchbookNote: string;
  postcardId?: number;
  cameraPreset: {
    position: [number, number, number];
    target: [number, number, number];
    fov: number;
  };
}

export const FLAME_CHOICES: Record<FlameId, FlameConfig> = {
  'honey-gold': {
    id: 'honey-gold',
    name: 'Honey-gold',
    subtitle: 'warm and steady',
    primaryHex: '#f6b94d',
    coreHex: '#fff7df',
    paperTintHex: '#f8dca0',
    bounceHex: '#d9822b',
    waterReflectionHex: '#f7c568',
    cobbleSpecularHex: '#e59a3e',
    fogHex: '#152038',
    threeLightColor: 0xf6b94d,
    threeBounceColor: 0xd9822b,
    threeFogColor: 0x111a2e,
    description:
      'Classic beeswax and amber warmth. Casts rich golden bounce light across weathered lime plaster, brass eyelets, and damp uneven cobblestones.'
  },
  'almost-white': {
    id: 'almost-white',
    name: 'Almost-white',
    subtitle: 'quiet moon',
    primaryHex: '#e8f1ff',
    coreHex: '#ffffff',
    paperTintHex: '#eef4ff',
    bounceHex: '#8fb2e8',
    waterReflectionHex: '#d8e8ff',
    cobbleSpecularHex: '#adc8f0',
    fogHex: '#101d36',
    threeLightColor: 0xe8f1ff,
    threeBounceColor: 0x7fa6e0,
    threeFogColor: 0x0e182e,
    description:
      'Silvery pearl illumination like moonlight caught in handmade mulberry paper. Brings out crisp architectural relief and tranquil silver water ripples.'
  },
  'deep-rose': {
    id: 'deep-rose',
    name: 'Deep rose',
    subtitle: 'soft and close',
    primaryHex: '#e87a90',
    coreHex: '#ffe3e9',
    paperTintHex: '#f5b8c4',
    bounceHex: '#b84a62',
    waterReflectionHex: '#f093a6',
    cobbleSpecularHex: '#d46880',
    fogHex: '#1c182e',
    threeLightColor: 0xe87a90,
    threeBounceColor: 0xb84a62,
    threeFogColor: 0x171429,
    description:
      'Warm rose-terracotta glow that feels intimate and sheltered. Softens aged wooden doors, terracotta pots, and brass wire into a rosy dusk.'
  },
  'green-gold': {
    id: 'green-gold',
    name: 'Green-gold',
    subtitle: 'fireflies nearby',
    primaryHex: '#c2de6b',
    coreHex: '#f7ffe0',
    // UNCONFIRMED: the original value was the invalid string '#dfna9e'. '#dfea9e' is the
    // most likely one-character correction but is NOT confirmed from any design source.
    // paperTintHex is currently not read anywhere in the app.
    paperTintHex: '#dfea9e',
    bounceHex: '#7ea338',
    waterReflectionHex: '#cce67a',
    cobbleSpecularHex: '#9ec24c',
    fogHex: '#11222b',
    threeLightColor: 0xc2de6b,
    threeBounceColor: 0x7ea338,
    threeFogColor: 0x0f1e26,
    description:
      'Luminous chartreuse-amber like orchard fireflies gathering near the lantern ribs. Awakens waxy leaves, mossy steps, and botanical shadows.'
  }
};

export const PREWRITTEN_WISH = {
  title: 'A Folded Note for the Road',
  text: 'May every quiet street you walk feel welcoming, and may the lights stay warm for as long as you wish to wander.',
  subtext: 'Handmade cotton-rag slip · Tucked inside the brass wire cradle'
};

export const POSTCARDS: PostcardData[] = [
  {
    id: 1,
    beatNumber: 5,
    slug: 'market-of-sounds',
    title: 'A market that sells only sounds',
    locationLabel: 'Postcard I · Beneath the Old Stone Arch',
    environmentBuild: 'sleeping-street',
    stampLabel: 'POSTAGE · ONE QUIET LISTENING',
    sketchCaption: 'Fig. 1 — Stoneware jars of rain on tin roofs & Tuesday morning tea-kettles.',
    frontQuote: 'No scales or coins here—only corked glass phials humming softly on linen cloths.',
    backGreeting: 'For Anamcara,',
    backBody: [
      'At the end of the sleeping street, the stalls have no fruit or spices—only rows of small earthenware jars stopped with beeswax.',
      'One merchant let me listen to the sound of rain beginning on warm courtyard tiles; another had a jar of pages turning in a quiet room while someone sleeps nearby.',
      'I left this sketch by the brass wind-bell so the stallholder would save the gentlest ones for whenever you pass through.'
    ],
    backSignoff: 'Left under the linen canopy',
    memoryArtifact: 'Corked glass phial: "First rain on warm slate & a distant train over the viaduct"',
    materialNotes: 'Pressed mulberry postcard stock, walnut ink wash, brass eyelet impression.'
  },
  {
    id: 2,
    beatNumber: 6,
    slug: 'sea-that-keeps-everything',
    title: 'A sea that keeps everything',
    locationLabel: 'Postcard II · The Stepped Water Ghat',
    environmentBuild: 'water',
    stampLabel: 'HARBOUR OFFICE · TIDE UNHURRIED',
    sketchCaption: 'Fig. 2 — Submerged stone steps where lost paper boats remain dry and whole.',
    frontQuote: 'Nothing that sinks here is ever lost; it simply waits below the ripples like a lantern behind glass.',
    backGreeting: 'For Anamcara,',
    backBody: [
      'The water at the bottom of the stone steps is as still as dark mirror-glass. When you hold the lantern close, you can see everything the town ever misplaced resting safely below.',
      'There are childhood paper boats with their creases still crisp, half-remembered melodies, and whole afternoons that ended too quickly.',
      'The water doesn’t keep them to hide them away—only so someone knows they are still whole.'
    ],
    backSignoff: 'Set beside the third mooring ring',
    memoryArtifact: 'Folded wax-paper boat floating alongside a reflection of the evening star',
    materialNotes: 'Heavy deckle-edge cotton card, indigo & gold-leaf water reflection study.'
  },
  {
    id: 3,
    beatNumber: 7,
    slug: 'shop-that-stocks-yesterday',
    title: 'A shop that only stocks yesterday',
    locationLabel: 'Postcard III · Courtyard Beyond the Gate',
    environmentBuild: 'market-gate',
    stampLabel: 'CURIOSITIES · LATE AFTERNOON DEPT.',
    sketchCaption: 'Fig. 3 — Multipaned bow window with shelves of bottled four-o’clock sunlight.',
    frontQuote: 'On the middle shelf: the exact warmth of a teacup held between both hands last winter.',
    backGreeting: 'For Anamcara,',
    backBody: [
      'Just inside the weathered stone gate is a narrow timber shopfront whose brass bell rings half a second before you touch the handle.',
      'The shelves are neatly labelled with small handwritten tags: "The five minutes after good news," "Sunlight on a wooden floor at 4:15 p.m.," and "A coat still warm from the radiator."',
      'Nothing is for sale because none of it has expired. The shopkeeper simply dusts the shelves so we can look in through the glass.'
    ],
    backSignoff: 'Tucked into the brass letter-slot',
    memoryArtifact: 'Small brass-rimmed lens holding the amber slant of Thursday afternoon light',
    materialNotes: 'Textured cream rag paper, sepia architectural elevation, embossed brass seal.'
  },
  {
    id: 4,
    beatNumber: 8,
    slug: 'library-of-unwritten-books',
    title: 'A library of books nobody wrote',
    locationLabel: 'Postcard IV · The Upper Timber Alcove',
    environmentBuild: 'market-gate',
    stampLabel: 'EX LIBRIS · UNWRITTEN FOLIOS',
    sketchCaption: 'Fig. 4 — Spiral wooden gallery & brass reading lectern under the roof lanterns.',
    frontQuote: 'Bound in soft linen: all the stories that were too peaceful to need an ending.',
    backGreeting: 'For Anamcara,',
    backBody: [
      'Up a short flight of worn teak stairs sits an open-air library overlooking the tiled roofs of the town.',
      'None of the books were written by authors. One shelf holds long walks taken without needing to say a word; another holds the complete anthology of laughing at the exact same moment.',
      'When you hold the lantern near a spine, the pages warm up as if someone just set the book down a moment ago.'
    ],
    backSignoff: 'Left as a bookmark on the brass lectern',
    memoryArtifact: 'Linen-bound miniature volume: "Conversations Held While Making Tea"',
    materialNotes: 'Laid bookbinding paper, fine nib cross-hatching, woven thread detail.'
  },
  {
    id: 5,
    beatNumber: 9,
    slug: 'her-street',
    title: 'Her street',
    locationLabel: 'Postcard V · The Familiar Window Ledge',
    environmentBuild: 'market-gate',
    stampLabel: 'HOMEWARD · NO POSTAGE REQUIRED',
    sketchCaption: 'Fig. 5 — The curve of the cobblestones where every lantern along the way stays lit.',
    frontQuote: 'Every small road in this town was only practicing how to curve back here.',
    backGreeting: 'For Anamcara,',
    backBody: [
      'The lane turns one last corner past the mossy garden wall, and suddenly the cobblestones look familiar.',
      'From this window ledge you can still see the faint glow of the sound-market arch, the quiet harbour water, the shop of yesterdays, and the high library roof.',
      'The lantern sits right here on the stone sill now. You don’t have to go anywhere or do a single thing—the whole town is simply glad you’re here.'
    ],
    backSignoff: 'Resting beside the warm lantern',
    memoryArtifact: 'The unfolded lantern itself, glowing steadily on the sill while the town lights stay on',
    materialNotes: 'Handmade fibrous paper illuminated from behind by the chosen flame.'
  }
];

export const STORY_BEATS: StoryBeat[] = [
  {
    beatNumber: 1,
    id: 'beat-1-doorstep-arrival',
    title: 'Dusk on the Doorstep',
    subtitle: 'At the doorstep',
    environmentBuild: 'doorstep',
    environmentLabel: 'The Weathered Doorstep',
    gesture: 'hold',
    gestureInstruction: 'Hold the folded lantern for 1 second to raise its bamboo ribs and handmade paper panels.',
    narrativeParagraphs: [
      'Blue hour settles gently over the lime-plaster threshold. On the warm stone step beside an aged wooden door rests a linen-bound sketchbook and a folded travelling lantern.',
      'Its four panels of handmade fibrous paper are tucked flat between fine brass wire rings, delicate bamboo corner ribs, and tiny brass eyelets.'
    ],
    sketchbookNote: 'Arrival at dusk. The air smells of damp stone, old teakwood, and night-blooming jasmine.',
    cameraPreset: {
      position: [0, 1.85, 5.1],
      target: [0, 0.9, 0],
      fov: 38
    }
  },
  {
    beatNumber: 2,
    id: 'beat-2-choose-flame',
    title: 'One Lantern, Four Quiet Flames',
    subtitle: 'At the doorstep',
    environmentBuild: 'doorstep',
    environmentLabel: 'The Weathered Doorstep',
    gesture: 'tap',
    gestureInstruction: 'Tap to choose the lantern’s flame colour. The same lantern will carry this light through the entire town.',
    narrativeParagraphs: [
      'With its tapered four-sided body unfolded, the diamond motif pressed into the handmade paper catches the last indigo light of dusk.',
      'Kindle the flame inside. Whichever colour you choose—honey-gold, almost-white, deep rose, or green-gold—it will warm the plaster walls, wet cobblestones, and quiet water ahead.'
    ],
    sketchbookNote: 'Testing the light against the doorstep plaster. Even the small brass eyelets catch the glow.',
    cameraPreset: {
      position: [0.35, 1.75, 4.6],
      target: [0, 0.95, 0],
      fov: 36
    }
  },
  {
    beatNumber: 3,
    id: 'beat-3-fold-wish',
    title: 'A Prewritten Wish for the Journey',
    subtitle: 'At the doorstep',
    environmentBuild: 'doorstep',
    environmentLabel: 'The Weathered Doorstep',
    gesture: 'tap',
    gestureInstruction: 'Tap the handmade paper note to fold it neatly into the lantern’s brass wire cradle.',
    narrativeParagraphs: [
      'Beside the sketchbook lies a small slip of cotton-rag paper, already written in quiet ink—no words asked of you, nothing to compose.',
      'Fold it once into the lantern so the light carries it along the road.'
    ],
    sketchbookNote: 'The note is tucked safely inside the lower brass ring. Time to step into the lane.',
    cameraPreset: {
      position: [-0.3, 1.8, 4.7],
      target: [0, 0.95, 0],
      fov: 36
    }
  },
  {
    beatNumber: 4,
    id: 'beat-4-sleeping-street',
    title: 'The Sleeping Street',
    subtitle: 'Along the sleeping street',
    environmentBuild: 'sleeping-street',
    environmentLabel: 'The Sleeping Street',
    gesture: 'drag',
    gestureInstruction: 'Drag gently across the street to guide the lantern light over the uneven cobblestones and old facades.',
    narrativeParagraphs: [
      'Beyond the doorstep, a narrow miniature street curves between two-storey houses of weathered plaster, carved timber balconies, and shuttered windows glowing softly above.',
      'As the lantern sways, its light glides across uneven cobblestones, terracotta pots of waxy leaves, and brass brackets along the sleeping walls.'
    ],
    sketchbookNote: 'Notice how the lantern colour bounces off the worn crowns of the cobblestones and the plaster arches.',
    cameraPreset: {
      position: [0.2, 2.2, 7.6],
      target: [0, 1.3, -1.5],
      fov: 40
    }
  },
  {
    beatNumber: 5,
    id: 'beat-5-sound-market',
    title: 'A Market That Sells Only Sounds',
    subtitle: 'First postcard · The Old Stone Arch',
    environmentBuild: 'sleeping-street',
    environmentLabel: 'The Old Stone Arch',
    gesture: 'tap',
    gestureInstruction: 'Tap to sketch the sound-stalls and leave the first postcard under the woven awning.',
    narrativeParagraphs: [
      'Where the sleeping street meets the old stone arch, linen awnings shelter rows of stoneware jars, brass bells, and stoppered glass phials.',
      'Each vessel holds a preserved sound: rain on warm slate, distant harbour bells, a cat purring on a folded sweater. The traveller draws the stall and leaves the first postcard.'
    ],
    sketchbookNote: 'Postcard I left beside the jar labelled "Leaves rustling just before an afternoon nap."',
    postcardId: 1,
    cameraPreset: {
      position: [-0.8, 1.9, 5.2],
      target: [-0.2, 1.3, -2.5],
      fov: 36
    }
  },
  {
    beatNumber: 6,
    id: 'beat-6-water-ghat',
    title: 'A Sea That Keeps Everything',
    subtitle: 'Second postcard · The Water Steps',
    environmentBuild: 'water',
    environmentLabel: 'The Water Steps',
    gesture: 'drag',
    gestureInstruction: 'Drag the lantern across the water’s edge to stir coloured reflections, then leave the second postcard.',
    narrativeParagraphs: [
      'Broad stone steps descend to a sheltered tide-basin where the water lies dark and glassy under the blue-hour sky.',
      'Hold the lantern over the parapet and the reflection reveals paper boats, brass compasses, and peaceful memories resting undamaged below the ripples.'
    ],
    sketchbookNote: 'Postcard II placed on the warm stone balustrade overlooking the floating lights.',
    postcardId: 2,
    cameraPreset: {
      position: [0.4, 2.1, 6.8],
      target: [0, 0.7, -1.2],
      fov: 39
    }
  },
  {
    beatNumber: 7,
    id: 'beat-7-yesterday-shop',
    title: 'A Shop That Only Stocks Yesterday',
    subtitle: 'Third postcard · Through the Stone Gate',
    environmentBuild: 'market-gate',
    environmentLabel: 'Through the Stone Gate',
    gesture: 'tap',
    gestureInstruction: 'Tap to shine the lantern through the multipaned bow window and leave the third postcard.',
    narrativeParagraphs: [
      'Passing through the mossy stone gate, the lane opens into a quiet courtyard where a bow-windowed timber shop glows like an amber cabinet.',
      'Inside sit neatly tagged jars of yesterday’s best hours—warm teacups, unhurried mornings, and four-o’clock sunlight. The traveller sketches the window and leaves the third postcard.'
    ],
    sketchbookNote: 'Postcard III slipped into the brass letterbox beside the multipaned bow window.',
    postcardId: 3,
    cameraPreset: {
      position: [-1.1, 1.9, 6.2],
      target: [-0.8, 1.3, -1.4],
      fov: 37
    }
  },
  {
    beatNumber: 8,
    id: 'beat-8-unwritten-library',
    title: 'A Library of Books Nobody Wrote',
    subtitle: 'Fourth postcard · The Timber Gallery',
    environmentBuild: 'market-gate',
    environmentLabel: 'The Timber Gallery',
    gesture: 'hold',
    gestureInstruction: 'Hold (1s) or tap to raise the lantern to the high brass lectern and leave the fourth postcard.',
    narrativeParagraphs: [
      'Above the courtyard gate, an open-air timber gallery cradles shelves of cloth-bound books that never needed to be written down.',
      'Their pages hold shared silences, quiet walks, and kindnesses remembered years later. The traveller rests the fourth postcard on the brass reading stand.'
    ],
    sketchbookNote: 'Postcard IV left on the upper gallery lectern among the linen-bound folios.',
    postcardId: 4,
    cameraPreset: {
      position: [1.0, 2.5, 5.8],
      target: [0.7, 2.0, -1.6],
      fov: 36
    }
  },
  {
    beatNumber: 9,
    id: 'beat-9-her-street-ending',
    title: 'Her Street',
    subtitle: 'Fifth postcard · The Long Way Home',
    environmentBuild: 'market-gate',
    environmentLabel: 'Her Street & the Lit Town',
    gesture: 'tap',
    gestureInstruction: 'Tap the fifth postcard on the window ledge as the lantern settles into place.',
    narrativeParagraphs: [
      'The cobblestone path curves gently around the garden wall and arrives at her street. All four places along the journey glow softly behind you in the blue-hour dusk.',
      'On the warm stone sill waits the fifth postcard, and beside it the lantern comes to rest—its light steady, welcoming, and unhurried.'
    ],
    sketchbookNote: 'Five postcards left along the way. The sketchbook closes; the lights stay on.',
    postcardId: 5,
    cameraPreset: {
      position: [0, 2.15, 6.4],
      target: [0, 1.35, -1.2],
      fov: 38
    }
  }
];
